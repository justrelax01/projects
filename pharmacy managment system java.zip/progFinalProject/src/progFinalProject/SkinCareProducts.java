package progFinalProject;
import java.util.*;
public class SkinCareProducts extends Products{
//	private ArrayList<String> allergicTo=new ArrayList<String>();
//	private ArrayList<String> goodFor=new ArrayList<String>();
	private boolean naturalOrChemical;
	private String category;
	
	public SkinCareProducts()
	{
		super();
	}
	public SkinCareProducts(String skinCareName)
	{
		super(skinCareName);
	}

	public SkinCareProducts(String skinCareName, Date produceDate, Date expireDate,
			String ingredients, double price,double wholeSalePrice,
			boolean naturalOrChemical,String category) {
		super(skinCareName,produceDate,expireDate,ingredients,price,wholeSalePrice);
//		this.allergicTo=allergicTo;
//		this.goodFor=goodFor;
		if(naturalOrChemical==true || naturalOrChemical==false)
		{
			this.naturalOrChemical=naturalOrChemical;
		}
		else {
			this.naturalOrChemical=true;
		}
		if(category.equalsIgnoreCase("serum") || category.equalsIgnoreCase("moisturizer") || category.equalsIgnoreCase("exfoliator")
                || category.equalsIgnoreCase("body lotion") || category.equalsIgnoreCase("eye cream")) {
            this.category = category;
        }
	}
	
//	public ArrayList<String> getAllergicTo() {
//		return allergicTo;
//	}
//
//	public void setAllergicTo(ArrayList<String> allergicTo) {
//		this.allergicTo = allergicTo;
//	}
//
//	public ArrayList<String> getGoodFor() {
//		return goodFor;
//	}
//
//	public void setGoodFor(ArrayList<String> goodFor) {
//		this.goodFor = goodFor;
//	}

	public String isNaturalOrChemical() {
		String a;
		if(naturalOrChemical==true)
		{
			a="Natural";
		}
		else
		{
			a="Chemical";
		}
		return a;
	}

	public void setNaturalOrChemical(boolean naturalOrChemical) {
		if(naturalOrChemical==true || naturalOrChemical==false)
		{
			this.naturalOrChemical=naturalOrChemical;
		}
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		if(category.equalsIgnoreCase("serum") || category.equalsIgnoreCase("moisturizer") || category.equalsIgnoreCase("exfoliator")
                || category.equalsIgnoreCase("body lotion") || category.equalsIgnoreCase("eye cream")) {
            this.category = category;
        }
		else
		{
			System.out.println("This category is not found, please enter a valid category.");
		}
	}
	public void addSkin(ArrayList<SkinCareProducts> skinList,SkinCareProducts s)
	{
		skinList.add(s);
	}
	public void removeSkin(ArrayList<SkinCareProducts>  skinList,int index)
	{
		skinList.remove(index-1);
	}
	public void printSkin(ArrayList<SkinCareProducts> skinList)
	{
		System.out.println("***The available skin care products***");
		for(int i=0;i<skinList.size();i++)
		{
			System.out.println("Skin care product "+(i+1)+" :\n"+skinList.get(i));
		}
	}
	public void searchForSkin(ArrayList<SkinCareProducts> skinList,String name)
	{
		boolean found=true;
		Medicine info=null;
		for(int i=0;i<skinList.size();i++)
		{
			if(skinList.get(i).getName().equalsIgnoreCase(name))
			{
				System.out.println("The skin care product of name "+name+" is found with the following info:\n"+skinList.get(i));
			}
			else
			{
				found=false;
			}
		}
		if(!found)
		{
			System.out.println("The skin care product of name "+name+" is not found.");
		}
		
	}
	public void printSpecificCategory(ArrayList<SkinCareProducts> skinList,String category)
	{
		System.out.println("SkinCare products of category "+category+" are: ");
		for(int i=0;i<skinList.size();i++)
		{
			if(skinList.get(i).getCategory().equalsIgnoreCase(category))
			{
				System.out.println((i+1)+")"+skinList.get(i).getName());
			}
		}
	}
	public void printAllCategories(ArrayList<SkinCareProducts> skinList)
	{
		int serum=0,moisturizer=0,texfoliator=0,bodyLotion=0,eyeCream=0;
		System.out.println("Serums\t\tMoisturizers\t\tTexfoliators\t\tBody Lotions\t\tEye Creams");
		for(int i=0;i<skinList.size();i++)
		{
			if(skinList.get(i).getCategory().equalsIgnoreCase("Serum"))
			{
				System.out.println((serum+1)+")"+skinList.get(i).getName());
				serum++;
			}
			else if(skinList.get(i).getCategory().equalsIgnoreCase("Moisturizer"))
			{
				System.out.println("\t\t"+(moisturizer+1)+")"+skinList.get(i).getName());
				moisturizer++;
			}
			else if(skinList.get(i).getCategory().equalsIgnoreCase("Texfoliator"))
			{
				System.out.println("\t\t\t\t"+(texfoliator+1)+")"+skinList.get(i).getName());
				texfoliator++;
			}
			else if(skinList.get(i).getCategory().equalsIgnoreCase("Body Lotion"))
			{
				System.out.println("\t\t\t\t\t\t"+(bodyLotion+1)+")"+skinList.get(i).getName());
				bodyLotion++;
			}
			else if(skinList.get(i).getCategory().equalsIgnoreCase("Eye Cream"))
			{
				System.out.println("\t\t\t\t\t\t\t\t"+(eyeCream+1)+")"+skinList.get(i).getName());
				eyeCream++;
			}
		}
	}
//	public void printGoodForSpecificSkin(ArrayList<SkinCareProducts> skinList,String skinType)
//	{
//		System.out.println("The skin care products that match with "+skinType+" skin are: ");
//		for(int i=0;i<skinList.size();i++)
//		{
//			for(int j=0;j<goodFor.size();j++)
//			{
//				if(goodFor.get(j).equalsIgnoreCase(skinType))
//				{
//					System.out.println((j+1)+"-"+skinList.get(i).getName());
//				}
//			}
//		}
//	}
//	public void printAllergicToSpecificSkin(ArrayList<SkinCareProducts> skinList,String skinType)
//	{
//		System.out.println("The skin care products that do not match with "+skinType+" skin are: ");
//		for(int i=0;i<skinList.size();i++)
//		{
//			for(int j=0;j<allergicTo.size();j++)
//			{
//				if(allergicTo.get(j).equalsIgnoreCase(skinType))
//				{
//					System.out.println((j+1)+"-"+skinList.get(i).getName());
//				}
//			}
//		}
//	}
	public void printNaturalAndChemical(ArrayList<SkinCareProducts> skinList)
	{
		int natural=0,chemical=0;
		System.out.println("Natural\t\tChemical");
		for(int i=0;i<skinList.size();i++)
		{
			if(skinList.get(i).isNaturalOrChemical().equalsIgnoreCase("Natural"))
			{
				System.out.println((natural+1)+"-"+skinList.get(i).getName());
			}
			else if(skinList.get(i).isNaturalOrChemical().equalsIgnoreCase("Chemical"))
			{
				System.out.println("\t\t"+(chemical+1)+"-"+skinList.get(i).getName());
			}
		}
	}
	public String toString()
	{
		String result= "SkinCare Product Info:\n"+super.toString()+"\nCategory: "+this.category+"\nNature: "+isNaturalOrChemical();
//		for(int i=0;i<goodFor.size();i++)
//		{
//			result+=(i+1)+"-"+goodFor.get(i)+"\n";
//		}
//		result+="\nCause allergic reaction for these types of skin: ";
//		for(int i=0;i<allergicTo.size();i++)
//		{
//			result+=(i+1)+"-"+allergicTo.get(i)+"\n";
//		}
//		result+="\n";
		return result;
		
	}
	
	
	
	

}
