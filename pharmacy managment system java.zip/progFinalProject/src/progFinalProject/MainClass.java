package progFinalProject;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;
import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;

import progFinalProject.Date;
public class MainClass {
	public static Scanner sc=new Scanner(System.in);
	static int choice;
	static ArrayList<Employee> pharmaList=new ArrayList<Employee>();
	static ArrayList<Employee> cashList=new ArrayList<Employee>();
	static ArrayList<Employee> skinList=new ArrayList<Employee>();
	static ArrayList<Medicine> medicineList=new ArrayList<Medicine>();
	static ArrayList<SkinCareProducts> skinProductsList=new ArrayList<SkinCareProducts>();
	static ArrayList<Integer> medicineQuantityList=new ArrayList<Integer>();
	static ArrayList<Integer> skinQuantityList=new ArrayList<Integer>();
	static ArrayList<String> medicineInStock=new ArrayList<String>();
	static ArrayList<String> medicineOutStock=new ArrayList<String>();
	static ArrayList<String> skinInStock=new ArrayList<String>();
	static ArrayList<String> skinOutStock=new ArrayList<String>();
	static MedicineStock medicineStock=new MedicineStock();
	static SkinStock skinStock=new SkinStock();
	static Client client=new Client();
	static Employee emp=new Employee();
	static Medicine med=new Medicine();
	static SkinCareProducts skinProduct=new SkinCareProducts();
	static Date date=new Date();
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
    static LocalDateTime now_Year = LocalDateTime.now();
	
    public static void StockSkinWriter()
    {
    	try {
			BufferedWriter writer=new BufferedWriter(new FileWriter("\\C:\\Users\\96135\\Desktop\\SkinStock.txt\\"));
			for(int i=0;i<skinProductsList.size();i++)
			{
				writer.write(skinProductsList.get(i).getName()+","+skinQuantityList.get(i)+"\n");
			}
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    public static void StockMedicineWriter()
    {
    	try {
			BufferedWriter writer=new BufferedWriter(new FileWriter("\\C:\\Users\\96135\\Desktop\\MedicineStock.txt\\"));
			for(int i=0;i<medicineList.size();i++)
			{
				writer.write(medicineList.get(i).getName()+","+medicineQuantityList.get(i)+"\n");
			}
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    public static void medicineWriter()
    {
    	try {
			BufferedWriter writer=new BufferedWriter(new FileWriter("\\C:\\Users\\96135\\Desktop\\Med.txt\\"));
			for(int i=0;i<medicineList.size();i++)
			{
				writer.write(medicineList.get(i).getName()+","+medicineList.get(i).getProduceDate()+","+
						medicineList.get(i).getExpireDate()+","+
						medicineList.get(i).getIngredients()+","+medicineList.get(i).getPrice()+","+
						medicineList.get(i).getWholeSalePrice()+","+medicineList.get(i).requirePrescription()+","+
						medicineList.get(i).getType()+"\n");
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    public static void skinWriter()
    {
    	try {
			BufferedWriter writer=new BufferedWriter(new FileWriter("\\C:\\Users\\96135\\Desktop\\SkinProduct.txt\\"));
			for(int i=0;i<skinProductsList.size();i++)
			{
				writer.write(skinProductsList.get(i).getName()+","+skinProductsList.get(i).getProduceDate()+","+
						skinProductsList.get(i).getExpireDate()+","+
						skinProductsList.get(i).getIngredients()+","+skinProductsList.get(i).getPrice()+","+
						skinProductsList.get(i).getWholeSalePrice()+","+skinProductsList.get(i).isNaturalOrChemical()+","+
						skinProductsList.get(i).getCategory()+"\n");
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
	public static void employeeWriter()
	{
		try {
			BufferedWriter writer=new BufferedWriter(new FileWriter("\\C:\\Users\\96135\\Desktop\\Emp.txt\\"));
			for(int i=0;i<pharmaList.size();i++)
			{
				writer.write(pharmaList.get(i).getFirstname()+","+pharmaList.get(i).getLastname()+
						","+pharmaList.get(i).getGender()+","+pharmaList.get(i).getDob()+
						","+pharmaList.get(i).getDoh()+","+pharmaList.get(i).getJob()+","+
						pharmaList.get(i).getPosition()+","+pharmaList.get(i).getSalary()+","+
						pharmaList.get(i).getDegree()+","+pharmaList.get(i).getYearsOfExp()+"\n");
			}
			
			for(int i=0;i<skinList.size();i++)
			{
				writer.write(skinList.get(i).getFirstname()+","+skinList.get(i).getLastname()+
						","+skinList.get(i).getGender()+","+skinList.get(i).getDob()+
						","+skinList.get(i).getDoh()+","+skinList.get(i).getJob()+","+
						skinList.get(i).getPosition()+","+skinList.get(i).getSalary()+","+
						skinList.get(i).getDegree()+","+skinList.get(i).getYearsOfExp()+"\n");
			}
			
			for(int i=0;i<cashList.size();i++)
			{
				writer.write(cashList.get(i).getFirstname()+","+cashList.get(i).getLastname()+
						","+cashList.get(i).getGender()+","+cashList.get(i).getDob()+
						","+cashList.get(i).getDoh()+","+cashList.get(i).getJob()+","+
						cashList.get(i).getPosition()+","+cashList.get(i).getSalary()+","+
						cashList.get(i).getDegree()+","+cashList.get(i).getYearsOfExp()+"\n");
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void design()
	{
	        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");  
	        LocalDateTime now = LocalDateTime.now();  
	         
	         for(int i = 0; i < 4; i++) {
	             System.out.println("\t╞  ╞");
	         }
	         System.out.print("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬    K & A");
	         System.out.print("\n  "+dtf.format(now)+"\n");
	         System.out.print("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬         PHARMACY");
	        System.out.print("\n");
	         for(int i = 0; i < 4; i++) {
	             System.out.println("\t╞  ╞");
	         }
	}
	
	public static void mainMenu() {
		System.out.println();
		System.out.println("•••••••••••••••••••••••••>MAIN MENU<•••••••••••••••••••••••••");
		System.out.println();
		System.out.print("1)About Employees\n"
				       + "2)About Products\n"
				       + "3)Check Medicines Stock\n"
				       + "4)Check SkinCare Products Stock\n"
				       + "5)About Pharmacy\n"
				       +"6)Client Services\n"
				       +"7)Exit System\n");
		do {
			System.out.print("\nEnter here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>7)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>7);
		switch(choice)
		{
		case 1:
			aboutEmployees();
			break;
		case 2:
			aboutProducts();
			break;
		case 3:
			checkStockMedicine();
			break;
		case 4:
			checkStockSkin();
			break;
		case 5:
			aboutPharmacy();
			break;
		case 6:
			clientServices();
			
			break;
		case 7:
			employeeWriter();
			medicineWriter();
			skinWriter();
			StockSkinWriter();
			StockMedicineWriter();
			System.out.println("Exiting System...");
			break;
		}
			
	}
		
	public static void clientServices()
	{
		System.out.println("1)Buy Products\n2)GoBack\n");
		do {
			System.out.print("Enter Here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>2)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>2);
		
		switch(choice)
		{
		case 1:
			buyProducts();
			break;
		case 2:
			mainMenu();
			break;
		}
	}
	public static void buyMedicine()
	{
		ArrayList<String> medicinePurchased=new ArrayList<String>();
		ArrayList<Integer> medicineQty=new ArrayList<Integer>();
		ArrayList<String> skinPurchased=new ArrayList<String>();
		ArrayList<Integer> skinQty=new ArrayList<Integer>();
		Date dateOfPurchase=new Date();
		int quantityMedicine,quantitySkin,dayPurchase,monthPurchase,yearPurchase;
		int yesOrNo = 0;
		DateTimeFormatter day = DateTimeFormatter.ofPattern("dd");  
		DateTimeFormatter month = DateTimeFormatter.ofPattern("MM"); 
		DateTimeFormatter year = DateTimeFormatter.ofPattern("yyyy"); 
        LocalDateTime now = LocalDateTime.now();
        dayPurchase=Integer.parseInt(day.format(now));
        monthPurchase=Integer.parseInt(month.format(now));
        yearPurchase=Integer.parseInt(year.format(now));
        int choiceProduct;
        
        dateOfPurchase = new Date(dayPurchase,monthPurchase,yearPurchase);
        
		
		
		for(int i=0;i<medicineList.size();i++)
		{
				System.out.println((i+1)+"-"+" Medicine Name: "+medicineList.get(i).getName()+" Price: "+medicineList.get(i).
						getPrice()+" $ ");
					
		}
		do {
			do {
				System.out.print("Enter Here: ");
				choiceProduct=sc.nextInt();
				if(choiceProduct<1 || choiceProduct>medicineList.size())
				{
					System.out.println("Error, Invalid choice please enter again.");
				}
			}while(choiceProduct<1 || choiceProduct>medicineList.size());
		
					if(medicineQuantityList.get(choiceProduct-1)>0)
					{
					do {
							System.out.print("Enter quantity: ");
							quantityMedicine=sc.nextInt();
							if(quantityMedicine<1 || quantityMedicine>medicineQuantityList.get(choiceProduct-1))
							{
								System.out.println("Error, Invalid quantity please enter again.");
							}
						}while(quantityMedicine<1 || quantityMedicine>medicineQuantityList.get(choiceProduct-1));
						medicineQty.add(quantityMedicine);
						medicinePurchased.add(medicineList.get(choiceProduct-1).getName());
						client.buyMedicine(medicineList, medicineQuantityList, choiceProduct, quantityMedicine, medicinePurchased,
								medicineQty);
						StockMedicineWriter();
						System.out.println(quantityMedicine+" piece(s) of "+medicineList.get(choiceProduct-1).getName()
								+" are purchased.");
					}
					
					else if(medicineQuantityList.get(choiceProduct-1)==0)
					{
					System.out.println("The medicine of name "+medicineList.get(choiceProduct-1).getName()+
							" is out of stock please check it.");
					}
					System.out.println("Would you like to add another medicine?");
					System.out.print("1)Yes\n2)No\n");
					
					do{
						System.out.print("Enter Here: ");
						yesOrNo=sc.nextInt();
						if(yesOrNo<1 || yesOrNo>2)
						{
							System.out.println("Error, Invalid entry please enter again.");
						}
					}while(yesOrNo<1 || yesOrNo>2);
			}while(yesOrNo!=2);
					
			
	}
	public static void buySkin()
	{
		ArrayList<String> medicinePurchased=new ArrayList<>();
		ArrayList<Integer> medicineQty=new ArrayList<>();
		ArrayList<String> skinPurchased=new ArrayList<>();
		ArrayList<Integer> skinQty=new ArrayList<>();
		Date dateOfPurchase=new Date();
		int quantityMedicine,quantitySkin,dayPurchase,monthPurchase,yearPurchase;
		int yesOrNo = 0;
		DateTimeFormatter day = DateTimeFormatter.ofPattern("dd");  
		DateTimeFormatter month = DateTimeFormatter.ofPattern("MM"); 
		DateTimeFormatter year = DateTimeFormatter.ofPattern("yyyy"); 
        LocalDateTime now = LocalDateTime.now();
        dayPurchase=Integer.parseInt(day.format(now));
        monthPurchase=Integer.parseInt(month.format(now));
        yearPurchase=Integer.parseInt(year.format(now));
        int choiceProduct;
        
        dateOfPurchase = new Date(dayPurchase,monthPurchase,yearPurchase);
        
		
		
		for(int i=0;i<skinProductsList.size();i++)
		{
				System.out.println((i+1)+"-"+" SkinCare Product Name: "+skinProductsList.get(i).getName()+" Price: "+
		skinProductsList.get(i).getPrice()+" $ ");
					
		}
		do {
			do {
				System.out.print("Enter Here: ");
				choiceProduct=sc.nextInt();
				if(choiceProduct<1 || choiceProduct>skinProductsList.size())
				{
					System.out.println("Error, Invalid choice please enter again.");
				}
			}while(choiceProduct<1 || choiceProduct>skinProductsList.size());
			
					if(skinQuantityList.get(choiceProduct-1)>0)
					{
						do {
							System.out.print("Enter quantity: ");
							quantitySkin=sc.nextInt();
							if(quantitySkin<1 || quantitySkin>skinQuantityList.get(choiceProduct-1))
							{
								System.out.println("Error, Invalid quantity please enter again.");
							}
						}while(quantitySkin<1 || quantitySkin>skinQuantityList.get(choiceProduct-1));
						skinQty.add(quantitySkin);
						skinPurchased.add(skinProductsList.get(choiceProduct-1).getName());
						client.buySkin(skinProductsList, skinQuantityList, choiceProduct, quantitySkin, skinPurchased,
								medicineQty);
						client=new Client(medicinePurchased,skinPurchased,medicineQty,skinQty,dateOfPurchase);
						StockSkinWriter();
						System.out.println(quantitySkin+" piece(s) of "+skinProductsList.get(choiceProduct-1).getName()
								+" are purchased.");
					}
					
					else if(skinQuantityList.get(choiceProduct-1)==0)
					{
					System.out.println("The skin care product of name "+skinProductsList.get(choiceProduct-1).getName()+
							" is out of stock please check it.");
					client=new Client(medicinePurchased,skinPurchased,medicineQty,skinQty,dateOfPurchase);
					StockSkinWriter();
					}
					System.out.println("Would you like to add another skin care product?");
					System.out.print("1)Yes\n2)No\n");
					
					do{
						System.out.print("Enter Here: ");
						yesOrNo=sc.nextInt();
						if(yesOrNo<1 || yesOrNo>2)
						{
							System.out.println("Error, Invalid entry please enter again.");
						}
					}while(yesOrNo<1 || yesOrNo>2);
			}while(yesOrNo!=2);
					
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
	}
	public static void buyProducts()
	{
		buyMedicine();
		buySkin();
	}
	public static void displayPharmaEmployee()
	{
		for(int i=0;i<pharmaList.size();i++)
		{
			System.out.print(pharmaList.get(i));
		}
		do {
			System.out.print("Enter 1 to go back to main menu:");
			choice=sc.nextInt();
			if(choice!=1)
			{
				System.out.print("\nInvalid entry.");
			}
			}while(choice!=1);
			if(choice==1)
			{
				mainMenu();
			}
	}
	public static void  displayCashEmployee()
	{
		for(int i=0;i<cashList.size();i++)
		{
			System.out.println(cashList.get(i));
		}
		do {
			System.out.print("Enter 1 to go back to main menu:");
			choice=sc.nextInt();
			if(choice!=1)
			{
				System.out.print("\nInvalid entry.");
			}
			}while(choice!=1);
			if(choice==1)
			{
				mainMenu();
			}
	}
	public static void  displaySkinEmployee()
	{
		for(int i=0;i<skinList.size();i++)
		{
			System.out.println(skinList.get(i));
		}
		do {
		System.out.print("Enter 1 to go back to main menu:");
		choice=sc.nextInt();
		if(choice!=1)
		{
			System.out.print("\nInvalid entry.");
		}
		}while(choice!=1);
		if(choice==1)
		{
			mainMenu();
		}
		
	}
	public static void displayAllEmployee()
	{
		if(pharmaList.size()>0)
			System.out.println("***PHARMAS***");
		for(int i=0;i<pharmaList.size();i++)
		{
			System.out.print(pharmaList.get(i));
		}
		if(cashList.size()>0)
			System.out.println("***CASHIERS***");
		for(int i=0;i<cashList.size();i++)
		{
			System.out.println(cashList.get(i));
		}
		if(skinList.size()>0)
			System.out.println("***SKINCARE SPECIALISTS***");
		for(int i=0;i<skinList.size();i++)
		{
			System.out.println(skinList.get(i));
		}
		do {
			System.out.print("Enter 1 to go back to main menu:");
			choice=sc.nextInt();
			if(choice!=1)
			{
				System.out.print("\nInvalid entry.");
			}
			}while(choice!=1);
			if(choice==1)
			{
				mainMenu();
			}
	}
	public static void managePharmaEmployee()
	{
		int empChoice,yearsOfExp;
		String update,degree,position;
		Date dob,doh;
		int year,month,day;
		double salary;
		char gender;
		for(int i=0;i<pharmaList.size();i++)
		{
			System.out.println((i+1)+"-"+"ID: "+pharmaList.get(i).getId()+" Name: "+pharmaList.get(i)
			.getFirstname()+" "+pharmaList.get(i).getLastname());
		}
		System.out.println("\n"+(pharmaList.size()+1)+"- GoBack");
		do {
			System.out.print("Enter Here: ");
			empChoice=sc.nextInt();
			if(empChoice<1 || empChoice>pharmaList.size()+1)
			{
				System.out.println("Error, Invalid entry please enter again.");
			}
		}while(empChoice<1 || empChoice>pharmaList.size()+1);
		if(empChoice<pharmaList.size()+1)
		{
			System.out.print("1)Edit FirstName\n"
					+ "2)Edit LastName\n"
					+ "3)Edit Date Of Birth\n"
					+ "4)Edit Date Of Hiring\n"
					+ "5)Edit Salary\n"
					+ "6)Edit Gender\n"
					+ "7)Edit Degree\n"
					+ "8)Edit Years Of Experience\n"
					+ "9)Edit Position\n"
					+ "10)GoBack\n");
			do {
				System.out.print("Enter Here: ");
				choice=sc.nextInt();
				if(choice<1 || choice>10)
				{
					System.out.println("Error, Invalid choice please enter again.");
				}
			}while(choice<1 || choice>10);
			switch(choice)
			{
			case 1:
				sc.nextLine();
				System.out.print("Enter the new first name for pharma "+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" "+pharmaList.get(empChoice-1).getId()+" : ");
				update=sc.nextLine();
				pharmaList.get(empChoice-1).setFirstname(update);
				pharmaList.get(empChoice-1).repairIdFirstName(update,pharmaList.get(empChoice-1).getTempIdNum());
				System.out.println("First name is successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 2:
				sc.nextLine();
				System.out.print("Enter the new last name for pharma "+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" "+pharmaList.get(empChoice-1).getId()+" : ");
				update=sc.nextLine();
				pharmaList.get(empChoice-1).setLastname(update);
				pharmaList.get(empChoice-1).repairIdLastName(update,pharmaList.get(empChoice-1).getTempIdNum());
				System.out.println("Last name is successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 3:
				System.out.println("Enter the new birth date for pharma"+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" "+pharmaList.get(empChoice-1).getId()+
						" "+pharmaList.get(empChoice-1).getDob());
				System.out.print("Enter new year of birth for pharma"+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" : ");
				do {
				year=sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.print("Error, Invalid year please enter again:");
				}
				}while(year<1900 || year>Integer.parseInt(dtf.format(now_Year)));
				System.out.print("Enter new month of birth for pharma"+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" : ");
				do {
					month=sc.nextInt();
					if(month<1 || month>12)
					{
						System.out.print("Error, Invalid month please enter again:");
					}
				}while(month<1 || month>12);
				System.out.print("Enter new day of birth for pharma"+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" : ");
				
				do {
					day=sc.nextInt();
					if(day<1 || day>31)
					{
						System.out.print("Error, Invalid day please enter again:");
					}
				}while(day<1 || day>31);
				dob = new Date(checkDay(day,month,year),month, year);
				pharmaList.get(empChoice-1).setDob(dob);
				System.out.println("Birth date is successfully updated.");
				employeeWriter();
				mainMenu();
				break;  
			case 4:
				System.out.println("Enter the new hire date for pharma"+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" "+pharmaList.get(empChoice-1).getId()+
						" "+pharmaList.get(empChoice-1).getDoh());
				System.out.print("Enter new year of hiring for pharma"+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" : ");
				do {
				year=sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.print("Error, Invalid year please enter again:");
				}
				}while(year<1900 || year>Integer.parseInt(dtf.format(now_Year)));
				System.out.print("Enter new month of hiring for pharma"+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" : ");
				do {
					month=sc.nextInt();
					if(month<1 || month>12)
					{
						System.out.print("Error, Invalid month please enter again:");
					}
				}while(month<1 || month>12);
				System.out.print("Enter new day of hiring for pharma"+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" : ");
				do {
					day=sc.nextInt();
					if(day<1 || day>31)
					{
						System.out.print("Error, Invalid day please enter again:");
					}
				}while(day<1 || day>31);
				doh = new Date(checkDay(day,month,year),month, year);
				System.out.println("Hire date is successfully updated.");
				pharmaList.get(empChoice-1).setDoh(doh);
				employeeWriter();
				mainMenu();
				break;
			case 5:
				System.out.print("Enter the new salary for pharma "+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" "+pharmaList.get(empChoice-1).getId()
						+" "+pharmaList.get(empChoice-1).getSalary()+" $  : ");
				do {
					salary=sc.nextDouble();
					if(salary<=0)
					{
						System.out.print("Error, Invalid salary please enter again: ");
					}
				}while(salary<=0);
				pharmaList.get(empChoice-1).setSalary(salary);
				System.out.println("Salary is successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 6:
				sc.nextLine();
				System.out.print("Enter the new gender(M/F) for pharma "+pharmaList.get(empChoice-1).getFirstname()
						+" "+pharmaList.get(empChoice-1).getLastname()+" "+pharmaList.get(empChoice-1).getId()
						+" "+pharmaList.get(empChoice-1).getGender()+" : ");
				do {
					gender=sc.next().charAt(0);
					if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
					{
						System.out.print("Error, Invalid gender please enter again: ");
					}
				}while(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'));
				pharmaList.get(empChoice-1).setGender(gender);
				System.out.println("Gender is successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 7:
				sc.nextLine();
				System.out.print("Enter the new degree(phd,master,bachelor,professor) for pharma "+
			pharmaList.get(empChoice-1).getFirstname()+" "+pharmaList.get(empChoice-1).getLastname()+" "+
			pharmaList.get(empChoice-1).getId()+" "+pharmaList.get(empChoice-1).getDegree()+" : ");
			do {
				degree=sc.nextLine();
				if(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")))
				{
					System.out.print("Error, Invalid degree please enter again: ");
				}
			}while(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")));
			pharmaList.get(empChoice-1).setDegree(degree);
			System.out.println("Degree is successfully updated.");
			employeeWriter();
			mainMenu();
			break;
			case 8:
				System.out.print("Enter the new year(s) of experience for pharma "+pharmaList.get(empChoice-1).getFirstname()+
				" "+pharmaList.get(empChoice-1).getLastname()+" "+pharmaList.get(empChoice-1).getId()+
				" "+pharmaList.get(empChoice-1).getYearsOfExp()+" years : ");
				do {
					yearsOfExp=sc.nextInt();
					if(yearsOfExp<0)
					{
						System.out.print("Error, Invalid years of experience please enter again: ");
					}
				}while(yearsOfExp<0);
				pharmaList.get(empChoice-1).setYearsOfExp(yearsOfExp);
				System.out.println("Year(s) of experience are successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 9:
				sc.nextLine();
				System.out.print("Enter the new position(Manager/Regular) for pharma "+pharmaList.get(empChoice-1).getFirstname()+
						" "+pharmaList.get(empChoice-1).getLastname()+" "+pharmaList.get(empChoice-1).getId()+
						" "+pharmaList.get(empChoice-1).getPosition()+" employee : ");
				do {
					position=sc.nextLine();
					if(!(position.equalsIgnoreCase("Manager") || position.equalsIgnoreCase("Regular")))
					{
						System.out.print("Error, Invalid position please enter again: ");
					}
				}while(!(position.equalsIgnoreCase("Manager") || position.equalsIgnoreCase("Regular")));
				pharmaList.get(empChoice-1).setPosition(position);
				System.out.println("Position successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 10:
				managePharmaEmployee();
				break;
				
			}
		}
		else
		{
			manageEmployee();
		}
	}
	public static void  manageCashEmployee()
	{
		int empChoice,yearsOfExp;
		String update,degree,position;
		Date dob,doh;
		int year,month,day;
		double salary;
		char gender;
		for(int i=0;i<cashList.size();i++)
		{
			System.out.println((i+1)+"-"+"ID: "+cashList.get(i).getId()+" Name: "+cashList.get(i)
			.getFirstname()+" "+cashList.get(i).getLastname());
		}
		System.out.println("\n"+(cashList.size()+1)+"- GoBack");
		do {
			System.out.print("Enter Here: ");
			empChoice=sc.nextInt();
			if(empChoice<1 || empChoice>cashList.size()+1)
			{
				System.out.println("Error, Invalid entry please enter again.");
			}
		}while(empChoice<1 || empChoice>cashList.size()+1);
		if(empChoice<cashList.size()+1)
		{
			System.out.print("1)Edit FirstName\n"
					+ "2)Edit LastName\n"
					+ "3)Edit Date Of Birth\n"
					+ "4)Edit Date Of Hiring\n"
					+ "5)Edit Salary\n"
					+ "6)Edit Gender\n"
					+ "7)Edit Degree\n"
					+ "8)Edit Years Of Experience\n"
					+ "9)Edit Position\n"
					+ "10)GoBack\n");
			do {
				System.out.print("Enter Here: ");
				choice=sc.nextInt();
				if(choice<1 || choice>10)
				{
					System.out.println("Error, Invalid choice please enter again.");
				}
			}while(choice<1 || choice>10);
			switch(choice)
			{
			case 1:
				sc.nextLine();
				System.out.print("Enter the new first name for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" "+cashList.get(empChoice-1).getId()+" : ");
				update=sc.nextLine();
				cashList.get(empChoice-1).setFirstname(update);
				cashList.get(empChoice-1).repairIdFirstName(update,cashList.get(empChoice-1).getTempIdNum());
				System.out.println("First name is successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 2:
				sc.nextLine();
				System.out.print("Enter the new last name for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" "+cashList.get(empChoice-1).getId()+" : ");
				update=sc.nextLine();
				cashList.get(empChoice-1).setLastname(update);
				cashList.get(empChoice-1).repairIdLastName(update,cashList.get(empChoice-1).getTempIdNum());
				System.out.println("Last name is successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 3:
				System.out.println("Enter the new birth date for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" "+cashList.get(empChoice-1).getId()+
						" "+cashList.get(empChoice-1).getDob());
				System.out.print("Enter new year of birth for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" : ");
				do {
				year=sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.print("Error, Invalid year please enter again: ");
				}
				}while(year<1900 || year>Integer.parseInt(dtf.format(now_Year)));
				System.out.print("Enter new month of birth for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" : ");
				do {
					month=sc.nextInt();
					if(month<1 || month>12)
					{
						System.out.print("Error, Invalid month please enter again:");
					}
				}while(month<1 || month>12);
				System.out.print("Enter new day of birth for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" : ");
				
				do {
					day=sc.nextInt();
					if(day<1 || day>31)
					{
						System.out.print("Error, Invalid day please enter again:");
					}
				}while(day<1 || day>31);
				dob = new Date(checkDay(day,month,year),month, year);
				cashList.get(empChoice-1).setDob(dob);
				System.out.println("Birth date is successfully updated.");
				employeeWriter();
				mainMenu();
				break;  
			case 4:
				System.out.println("Enter the new hire date for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" "+cashList.get(empChoice-1).getId()+
						" "+cashList.get(empChoice-1).getDoh());
				System.out.print("Enter new year of hiring for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" : ");
				do {
				year=sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.print("Error, Invalid year please enter again:");
				}
				}while(year<1900 || year>Integer.parseInt(dtf.format(now_Year)));
				System.out.print("Enter new month of hiring for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" : ");
				do {
					month=sc.nextInt();
					if(month<1 || month>12)
					{
						System.out.print("Error, Invalid month please enter again:");
					}
				}while(month<1 || month>12);
				System.out.print("Enter new day of hiring for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" : ");
				do {
					day=sc.nextInt();
					if(day<1 || day>31)
					{
						System.out.print("Error, Invalid day please enter again:");
					}
				}while(day<1 || day>31);
				doh = new Date(checkDay(day,month,year),month, year);
				System.out.println("Hire date is successfully updated.");
				cashList.get(empChoice-1).setDoh(doh);
				employeeWriter();
				mainMenu();
				break;
			case 5:
				System.out.print("Enter the new salary for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" "+cashList.get(empChoice-1).getId()
						+" "+cashList.get(empChoice-1).getSalary()+" $  : ");
				do {
					salary=sc.nextDouble();
					if(salary<=0)
					{
						System.out.print("Error, Invalid salary please enter again: ");
					}
				}while(salary<=0);
				cashList.get(empChoice-1).setSalary(salary);
				System.out.println("Salary is successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 6:
				sc.nextLine();
				System.out.print("Enter the new gender(M/F) for cashier "+cashList.get(empChoice-1).getFirstname()
						+" "+cashList.get(empChoice-1).getLastname()+" "+cashList.get(empChoice-1).getId()
						+" "+cashList.get(empChoice-1).getGender()+" : ");
				do {
					gender=sc.next().charAt(0);
					if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
					{
						System.out.print("Error, Invalid gender please enter again: ");
					}
				}while(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'));
				cashList.get(empChoice-1).setGender(gender);
				System.out.println("Gender is successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 7:
				sc.nextLine();
				System.out.print("Enter the new degree(phd,master,bachelor,professor) for cashier "+
						cashList.get(empChoice-1).getFirstname()+" "+cashList.get(empChoice-1).getLastname()+" "+
						cashList.get(empChoice-1).getId()+" "+cashList.get(empChoice-1).getDegree()+" : ");
			do {
				degree=sc.nextLine();
				if(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")))
				{
					System.out.print("Error, Invalid degree please enter again: ");
				}
			}while(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")));
			cashList.get(empChoice-1).setDegree(degree);
			System.out.println("Degree is successfully updated.");
			employeeWriter();
			mainMenu();
			break;
			case 8:
				System.out.print("Enter the new year(s) of experience for cashier "+cashList.get(empChoice-1).getFirstname()+
				" "+cashList.get(empChoice-1).getLastname()+" "+cashList.get(empChoice-1).getId()+
				" "+cashList.get(empChoice-1).getYearsOfExp()+" years : ");
				do {
					yearsOfExp=sc.nextInt();
					if(yearsOfExp<0)
					{
						System.out.print("Error, Invalid years of experience please enter again: ");
					}
				}while(yearsOfExp<0);
				cashList.get(empChoice-1).setYearsOfExp(yearsOfExp);
				System.out.println("Year(s) of experience are successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 9:
				sc.nextLine();
				System.out.print("Enter the new position(Manager/Regular) for cashier "+cashList.get(empChoice-1).getFirstname()+
						" "+cashList.get(empChoice-1).getLastname()+" "+cashList.get(empChoice-1).getId()+
						" "+cashList.get(empChoice-1).getPosition()+" employee : ");
				do {
					position=sc.nextLine();
					if(!(position.equalsIgnoreCase("Manager") || position.equalsIgnoreCase("Regular")))
					{
						System.out.print("Error, Invalid position please enter again: ");
					}
				}while(!(position.equalsIgnoreCase("Manager") || position.equalsIgnoreCase("Regular")));
				cashList.get(empChoice-1).setPosition(position);
				System.out.println("Position successfully updated.");
				employeeWriter();
				mainMenu();
				break;
			case 10:
				managePharmaEmployee();
				break;
				
			}
		}
		else
		{
			manageEmployee();
		}
	}
	public static void  manageSkinEmployee()
	{
		int empChoice,yearsOfExp;
		String update,degree,position;
		Date dob,doh;
		int year,month,day;
		double salary;
		char gender;
		for(int i=0;i<skinList.size();i++)
		{
			System.out.println((i+1)+"-"+"ID: "+skinList.get(i).getId()+" Name: "+skinList.get(i)
			.getFirstname()+" "+skinList.get(i).getLastname());
		}
		System.out.println("\n"+(skinList.size()+1)+"- GoBack");
		do {
			System.out.print("Enter Here: ");
			empChoice=sc.nextInt();
			if(empChoice<1 || empChoice>skinList.size()+1)
			{
				System.out.println("Error, Invalid entry please enter again.");
			}
		}while(empChoice<1 || empChoice>skinList.size()+1);
		if(empChoice<skinList.size()+1)
		{
			System.out.print("1)Edit FirstName\n"
					+ "2)Edit LastName\n"
					+ "3)Edit Date Of Birth\n"
					+ "4)Edit Date Of Hiring\n"
					+ "5)Edit Salary\n"
					+ "6)Edit Gender\n"
					+ "7)Edit Degree\n"
					+ "8)Edit Years Of Experience\n"
					+ "9)Edit Position\n"
					+ "10)GoBack\n");
			do {
				System.out.print("Enter Here: ");
				choice=sc.nextInt();
				if(choice<1 || choice>10)
				{
					System.out.println("Error, Invalid choice please enter again.");
				}
			}while(choice<1 || choice>10);
			switch(choice)
			{
			case 1:
				sc.nextLine();
				System.out.print("Enter the new first name for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" "+skinList.get(empChoice-1).getId()+" : ");
				update=sc.nextLine();
				skinList.get(empChoice-1).setFirstname(update);
				skinList.get(empChoice-1).repairIdFirstName(update,skinList.get(empChoice-1).getTempIdNum());
				System.out.println("First name is successfully updated.");
				employeeWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;
			case 2:
				sc.nextLine();
				System.out.print("Enter the new last name for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" "+skinList.get(empChoice-1).getId()+" : ");
				update=sc.nextLine();
				skinList.get(empChoice-1).setLastname(update);
				skinList.get(empChoice-1).repairIdLastName(update,skinList.get(empChoice-1).getTempIdNum());
				System.out.println("Last name is successfully updated.");
				employeeWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;
			case 3:
				System.out.println("Enter the new birth date for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" "+skinList.get(empChoice-1).getId()+
						" "+skinList.get(empChoice-1).getDob());
				System.out.print("Enter new year of birth for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" : ");
				do {
				year=sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.print("Error, Invalid year please enter again:");
				}
				}while(year<1900 || year>Integer.parseInt(dtf.format(now_Year)));
				System.out.print("Enter new month of birth for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" : ");
				do {
					month=sc.nextInt();
					if(month<1 || month>12)
					{
						System.out.print("Error, Invalid month please enter again:");
					}
				}while(month<1 || month>12);
				System.out.print("Enter new day of birth for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" : ");
				
				do {
					day=sc.nextInt();
					if(day<1 || day>31)
					{
						System.out.print("Error, Invalid day please enter again:");
					}
				}while(day<1 || day>31);
				dob = new Date(checkDay(day,month,year),month, year);
				skinList.get(empChoice-1).setDob(dob);
				System.out.println("Birth date is successfully updated.");
				employeeWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;  
			case 4:
				System.out.println("Enter the new hire date for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" "+skinList.get(empChoice-1).getId()+
						" "+skinList.get(empChoice-1).getDoh());
				System.out.print("Enter new year of hiring for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" : ");
				do {
				year=sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.print("Error, Invalid year please enter again:");
				}
				}while(year<1900 || year>Integer.parseInt(dtf.format(now_Year)));
				System.out.print("Enter new month of hiring for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" : ");
				do {
					month=sc.nextInt();
					if(month<1 || month>12)
					{
						System.out.print("Error, Invalid month please enter again:");
					}
				}while(month<1 || month>12);
				System.out.print("Enter new day of hiring for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" : ");
				do {
					day=sc.nextInt();
					if(day<1 || day>31)
					{
						System.out.print("Error, Invalid day please enter again:");
					}
				}while(day<1 || day>31);
				doh = new Date(checkDay(day,month,year),month, year);
				System.out.println("Hire date is successfully updated.");
				skinList.get(empChoice-1).setDoh(doh);
				employeeWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;
			case 5:
				System.out.print("Enter the new salary for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" "+skinList.get(empChoice-1).getId()
						+" "+skinList.get(empChoice-1).getSalary()+" $  : ");
				do {
					salary=sc.nextDouble();
					if(salary<=0)
					{
						System.out.print("Error, Invalid salary please enter again: ");
					}
				}while(salary<=0);
				skinList.get(empChoice-1).setSalary(salary);
				System.out.println("Salary is successfully updated.");
				employeeWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;
			case 6:
				sc.nextLine();
				System.out.print("Enter the new gender(M/F) for skin care specialist "+skinList.get(empChoice-1).getFirstname()
						+" "+skinList.get(empChoice-1).getLastname()+" "+skinList.get(empChoice-1).getId()
						+" "+skinList.get(empChoice-1).getGender()+" : ");
				do {
					gender=sc.next().charAt(0);
					if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
					{
						System.out.print("Error, Invalid gender please enter again: ");
					}
				}while(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'));
				skinList.get(empChoice-1).setGender(gender);
				System.out.println("Gender is successfully updated.");
				employeeWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;
			case 7:
				sc.nextLine();
				System.out.print("Enter the new degree(phd,master,bachelor,professor) for skin care specialist "+
						skinList.get(empChoice-1).getFirstname()+" "+skinList.get(empChoice-1).getLastname()+" "+
						skinList.get(empChoice-1).getId()+" "+skinList.get(empChoice-1).getDegree()+" : ");
			do {
				degree=sc.nextLine();
				if(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")))
				{
					System.out.print("Error, Invalid degree please enter again: ");
				}
			}while(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")));
			skinList.get(empChoice-1).setDegree(degree);
			System.out.println("Degree is successfully updated.");
			employeeWriter();
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
			case 8:
				System.out.print("Enter the new year(s) of experience for skin care specialist "+skinList.get(empChoice-1).getFirstname()+
				" "+skinList.get(empChoice-1).getLastname()+" "+skinList.get(empChoice-1).getId()+
				" "+skinList.get(empChoice-1).getYearsOfExp()+" years : ");
				do {
					yearsOfExp=sc.nextInt();
					if(yearsOfExp<0)
					{
						System.out.print("Error, Invalid years of experience please enter again: ");
					}
				}while(yearsOfExp<0);
				skinList.get(empChoice-1).setYearsOfExp(yearsOfExp);
				System.out.println("Year(s) of experience are successfully updated.");
				employeeWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;
			case 9:
				sc.nextLine();
				System.out.print("Enter the new position(Manager/Regular) for skin care specialist "+
				skinList.get(empChoice-1).getFirstname()+
				" "+skinList.get(empChoice-1).getLastname()+" "+skinList.get(empChoice-1).getId()+
				" "+skinList.get(empChoice-1).getPosition()+" employee : ");
				do {
					position=sc.nextLine();
					if(!(position.equalsIgnoreCase("Manager") || position.equalsIgnoreCase("Regular")))
					{
						System.out.print("Error, Invalid position please enter again: ");
					}
				}while(!(position.equalsIgnoreCase("Manager") || position.equalsIgnoreCase("Regular")));
				skinList.get(empChoice-1).setPosition(position);
				System.out.println("Position successfully updated.");
				employeeWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;
			case 10:
				managePharmaEmployee();
				break;
				
			}
		}
		else
		{
			manageEmployee();
		}
	}
	public static void removeEmployee()
	{
		System.out.print("1)Remove Pharma\n2)Remove Cashier\n3)Remove SkinCare Specialist\n4)Go back\n");
		do {
			System.out.print("Enter here: ");
			choice = sc.nextInt();
			if(choice < 1 || choice > 4) {
				System.out.println("Error ! Invalid choice please enter again");
			}
		}while(choice < 1 || choice > 4);
		switch(choice) {
		case 1: removePharmaEmployee();
			break;
		case 2: removeCashEmployee();
		break;
		case 3: removeSkinEmployee();
		break;
		case 4: aboutEmployees();
		break;

		}
		
		
		
	}
	public static void removePharmaEmployee()
	{
		for(int i=0;i<pharmaList.size();i++)
		{
			System.out.println((i+1)+"-"+" ID: "+pharmaList.get(i).getId()+" Name: "+pharmaList.get(i).getFirstname()
					+" "+pharmaList.get(i).getLastname());
		}
		System.out.println((pharmaList.size()+1)+"- GoBack");
		System.out.println("Which employee do you want to remove ?");
		do {
		System.out.print("\nEnter Here: ");
		choice=sc.nextInt();
		if(choice<1 || choice>pharmaList.size()+1)
		{
			System.out.println("Please enter a number between 1 and "+(pharmaList.size()+1)+".");
		}
		}while(choice<1 || choice>pharmaList.size()+1);
		if(choice==pharmaList.size()+1)
		{
			aboutEmployees();
		}
		else
		{
			System.out.println("Pharma of ID "+pharmaList.get(choice-1).getId()+" and name "
					+pharmaList.get(choice-1).getFirstname()+" "+pharmaList.get(choice-1).getLastname()
					+" has been removed.");
			emp.removeEmployee(pharmaList,choice);
			employeeWriter();
			mainMenu();
		}
	}
	public static void removeCashEmployee()
	{
		for(int i=0;i<cashList.size();i++)
		{
			System.out.println((i+1)+"-"+" ID: "+cashList.get(i).getId()+" Name: "+cashList.get(i).getFirstname()
					+" "+cashList.get(i).getLastname());
		}
		System.out.println((cashList.size()+1)+"- GoBack");
		System.out.println("Which employee do you want to remove ?");
		do {
		System.out.print("\nEnter Here: ");
		choice=sc.nextInt();
		if(choice<1 || choice>cashList.size()+1)
		{
			System.out.println("Please enter a number between 1 and "+(cashList.size()+1)+".");
		}
		}while(choice < 1 || choice > cashList.size()+1);
		if(choice == cashList.size()+1)
		{
			aboutEmployees();
		}
		else
		{
			System.out.println("Cashier of ID "+cashList.get(choice-1).getId()+" and name "
					+cashList.get(choice-1).getFirstname()+" "+cashList.get(choice-1).getLastname()+" has been removed.");
			emp.removeEmployee(cashList,choice);
			employeeWriter();
			mainMenu();
		}
	}
	public static void removeSkinEmployee()
	{
		for(int i=0;i<skinList.size();i++)
		{
			System.out.println((i+1)+"-"+" ID: "+skinList.get(i).getId()+" Name: "+skinList.get(i).getFirstname()
					+" "+skinList.get(i).getLastname());
		}
		System.out.println((skinList.size()+1)+"- GoBack");
		System.out.println("Which employee do you want to remove ?");
		do {
		System.out.print("\nEnter Here: ");
		choice=sc.nextInt();
		if(choice<1 || choice>skinList.size()+1)
		{
			System.out.println("Please enter a number between 1 and "+(skinList.size()+1)+".");
		}
		}while(choice<1 || choice>skinList.size()+1);
		if(choice==skinList.size()+1)
		{
			aboutEmployees();
		}
		else
		{
			System.out.println("Skin care specialist of ID "+skinList.get(choice-1).getId()+" and name "
					+skinList.get(choice-1).getFirstname()+" "+skinList.get(choice-1).getLastname()
					+" has been removed.");
			emp.removeEmployee(skinList,choice);
			employeeWriter();
			mainMenu();
		}
	}
	public static void addPharmaEmployee()
	{
		System.out.print("1)Add Regular Pharma\n2)Add Manager Pharma\n3)GoBack\n");
		do {
			System.out.print("Enter here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>3)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>3);
		switch(choice)
		{
		case 1:
			addRegularPharma();
			break;
		case 2:
			addManagerPharma();
			break;
		case 3:
			addEmployee();
		}
	}
	public static void addCashEmployee()
	{
		System.out.print("1)Add Regular Cashier\n2)Add Manager Cashier\n3)GoBack\n");
		do {
			System.out.print("Enter here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>3)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>3);
		switch(choice)
		{
		case 1:
			addRegularCash();
			break;
		case 2:
			addManagerCash();
			break;
		case 3:
			addEmployee();
		}
	}
	public static void addSkinEmployee()
	{
		System.out.print("1)Add Regular SkinCare Specialist\n2)Add Manager SkinCare Specialist\n3)GoBack\n");
		do {
			System.out.print("Enter here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>3)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>3);
		switch(choice)
		{
		case 1:
			addRegularSkin();
			break;
		case 2:
			addManagerSkin();
			break;
		case 3:
			addEmployee();
		}
	}
	public static void addRegularPharma()
	{
		String firstname,lastname, degree;
		char gender;
		Date dob,doh;
		double salary;
		int yearsOfExp;
		sc.nextLine();
		System.out.print("Enter pharma's first name: ");
		firstname=sc.nextLine();
		System.out.print("Enter pharma's last name: ");
		lastname=sc.nextLine();
		do {
			System.out.print("Enter pharma's degree(phd,master,bachelor,professor): ");
			degree=sc.nextLine();
			if(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")))
			{
				System.out.println("Error, please enter a valid degree.");
			}
		}while(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
				|| degree.equalsIgnoreCase("professor")));
		do {
			System.out.print("Enter salary for "+firstname+" "+lastname+": ");
			salary=sc.nextDouble();
			if(salary<=0)
			{
				System.out.println("Error, please enter a valid salary.");
			}
		}while(salary<=0);
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
        LocalDateTime now_Year = LocalDateTime.now();
        
		do {
			System.out.print("Enter years of experience for "+firstname+" "+lastname+": ");
			yearsOfExp=sc.nextInt();
			if(yearsOfExp<0)
			{
				System.out.println("Error, please enter a valid number of years.");
			}
		}while(yearsOfExp<0);
		sc.nextLine();
		do {
			System.out.print("Enter gender(M/F) of "+firstname+" "+lastname+": ");
			gender=sc.next().charAt(0);
			if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
			{
				System.out.println("Error, please enter a valid gender.");
			}
		}while(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'));
		int year, month, day;
		sc.nextLine();
		do {
			System.out.print("Enter year of birth of "+ firstname+ " " + lastname + ": ");
			year = sc.nextInt();
			if(year<1900 || year>Integer.parseInt(dtf.format(now_Year))) {
				System.out.println("Error, please enter a valid year.");
			}
		}while(year<1900 || year>Integer.parseInt(dtf.format(now_Year)));
		do {
			System.out.print("Enter month of birth of "+ firstname+ " " + lastname + ": ");
			month = sc.nextInt();
			if(month < 1 || month > 12) {
				System.out.println("Error, please enter a valid month.");
			}
		}while(month < 1 || month > 12);
		do {
			System.out.print("Enter day of birth of "+ firstname+ " " + lastname + ": ");
			 day = sc.nextInt();
			 if(day < 1 || day > 31) {
				 System.out.println("Error, please enter a valid day.");
			 }
			
		}while(day < 1 || day > 31);
		 dob = new Date(checkDay(day,month,year),month, year);
		 //sc.nextLine();
		 
		 do {
				System.out.print("Enter year of hiring of "+ firstname+ " " + lastname + ": ");
				year = sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now_Year))) {
					System.out.println("Error, please enter a valid year.");
				}
			}while(year<1900 || year>Integer.parseInt(dtf.format(now_Year)));
			do {
				System.out.print("Enter month of hiring of "+ firstname+ " " + lastname + ": ");
				month = sc.nextInt();
				if(month < 1 || month > 12) {
					System.out.println("Error, please enter a valid month.");
				}
			}while(month < 1 || month > 12);
			do {
				System.out.print("Enter day of hiring of "+ firstname+ " " + lastname + ": ");
				 day = sc.nextInt();
				 if(day < 1 || day > 31) {
					 System.out.println("Error, please enter a valid day.");
				 }
				
			}while(day < 1 || day > 31);
			 doh = new Date(checkDay(day,month,year),month, year);
			 
			 Employee p=new Employee(firstname,lastname,gender,dob,doh,"Pharma","Regular",salary,degree,yearsOfExp);
			 emp.addEmployee(pharmaList,p);
			 employeeWriter();//write to file
			 System.out.println("Regular Pharma of name "+firstname+" "+lastname+" and id "+p.getId()+" has been added.");
			 mainMenu();
		 
	}
	public static void addManagerPharma()
	{
		String firstname,lastname, degree;
		char gender;
		Date dob,doh;
		double salary;
		int yearsOfExp;
		sc.nextLine();
		System.out.print("Enter pharma's first name: ");
		firstname=sc.nextLine();
		System.out.print("Enter pharma's last name: ");
		lastname=sc.nextLine();
		do {
			System.out.print("Enter pharma's degree(phd,master,bachelor,professor): ");
			degree=sc.nextLine();
			if(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")))
			{
				System.out.println("Error, please enter a valid degree.");
			}
		}while(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
				|| degree.equalsIgnoreCase("professor")));
		do {
			System.out.print("Enter salary for "+firstname+" "+lastname+": ");
			salary=sc.nextDouble();
			if(salary<=0)
			{
				System.out.println("Error, please enter a valid salary.");
			}
		}while(salary<=0);
		do {
			System.out.print("Enter years of experience for "+firstname+" "+lastname+": ");
			yearsOfExp=sc.nextInt();
			if(yearsOfExp<0)
			{
				System.out.println("Error, please enter a valid number of years.");
			}
		}while(yearsOfExp<0);
		sc.nextLine();
		do {
			System.out.print("Enter gender(M/F) of "+firstname+" "+lastname+": ");
			gender=sc.next().charAt(0);
			if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
			{
				System.out.println("Error, please enter a valid gender.");
			}
		}while(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'));
		int year, month, day;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
        LocalDateTime now = LocalDateTime.now();
		do {
			System.out.print("Enter year of birth of "+ firstname+ " " + lastname + ": ");
			year = sc.nextInt();
			if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
				System.out.println("Error, please enter a valid year.");
			}
		}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
		do {
			System.out.print("Enter month of birth of "+ firstname+ " " + lastname + ": ");
			month = sc.nextInt();
			if(month < 1 || month > 12) {
				System.out.println("Error, please enter a valid month.");
			}
		}while(month < 1 || month > 12);
		do {
			System.out.print("Enter day of birth of "+ firstname+ " " + lastname + ": ");
			 day = sc.nextInt();
			 if(day < 1 || day > 31) {
				 System.out.println("Error, please enter a valid day.");
			 }
			
		}while(day < 1 || day > 31);
		 dob = new Date(checkDay(day,month,year),month, year);
		 sc.nextLine();
		 
		 do {
				System.out.print("Enter year of hiring of "+ firstname+ " " + lastname + ": ");
				year = sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
					System.out.println("Error, please enter a valid year.");
				}
			}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
			do {
				System.out.print("Enter month of hiring of "+ firstname+ " " + lastname + ": ");
				month = sc.nextInt();
				if(month < 1 || month > 12) {
					System.out.println("Error, please enter a valid month.");
				}
			}while(month < 1 || month > 12);
			do {
				System.out.print("Enter day of hiring of "+ firstname+ " " + lastname + ": ");
				 day = sc.nextInt();
				 if(day < 1 || day > 31) {
					 System.out.println("Error, please enter a valid day.");
				 }
				
			}while(day < 1 || day > 31);
			 doh = new Date(checkDay(day,month,year),month, year);
			 
			 Employee p=new Employee(firstname,lastname,gender,dob,doh,"Pharma","Manager",salary,degree,yearsOfExp);
			 emp.addEmployee(pharmaList,p);
			 employeeWriter();
			 System.out.println("Manager Pharma of name "+firstname+" "+lastname+" and id "+p.getId()+" has been added.");
			 mainMenu();
	}
	public static void addRegularCash()
	{
		String firstname,lastname, degree;
		char gender;
		Date dob,doh;
		double salary;
		int yearsOfExp;
		sc.nextLine();
		System.out.print("Enter cashier's first name: ");
		firstname=sc.nextLine();
		System.out.print("Enter cashier's last name: ");
		lastname=sc.nextLine();
		do {
			System.out.print("Enter cashier's degree(phd,master,bachelor,professor): ");
			degree=sc.nextLine();
			if(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")))
			{
				System.out.println("Error, please enter a valid degree.");
			}
		}while(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
				|| degree.equalsIgnoreCase("professor")));
		do {
			System.out.print("Enter salary for "+firstname+" "+lastname+": ");
			salary=sc.nextDouble();
			if(salary<=0)
			{
				System.out.println("Error, please enter a valid salary.");
			}
		}while(salary<=0);
		do {
			System.out.print("Enter years of experience for "+firstname+" "+lastname+": ");
			yearsOfExp=sc.nextInt();
			if(yearsOfExp<0)
			{
				System.out.println("Error, please enter a valid number of years.");
			}
		}while(yearsOfExp<0);
		sc.nextLine();
		do {
			System.out.print("Enter gender(M/F) of "+firstname+" "+lastname+": ");
			gender=sc.next().charAt(0);
			if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
			{
				System.out.println("Error, please enter a valid gender.");
			}
		}while(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'));
		int year, month, day;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
        LocalDateTime now = LocalDateTime.now();
		do {
			System.out.print("Enter year of birth of "+ firstname+ " " + lastname + ": ");
			year = sc.nextInt();
			if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
				System.out.println("Error, please enter a valid year.");
			}
		}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
		do {
			System.out.print("Enter month of birth of "+ firstname+ " " + lastname + ": ");
			month = sc.nextInt();
			if(month < 1 || month > 12) {
				System.out.println("Error, please enter a valid month.");
			}
		}while(month < 1 || month > 12);
		do {
			System.out.print("Enter day of birth of "+ firstname+ " " + lastname + ": ");
			 day = sc.nextInt();
			 if(day < 1 || day > 31) {
				 System.out.println("Error, please enter a valid day.");
			 }
			
		}while(day < 1 || day > 31);
		 dob = new Date(checkDay(day,month,year),month, year);
		 sc.nextLine();
		 
		 do {
				System.out.print("Enter year of hiring of "+ firstname+ " " + lastname + ": ");
				year = sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
					System.out.println("Error, please enter a valid year.");
				}
			}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
			do {
				System.out.print("Enter month of hiring of "+ firstname+ " " + lastname + ": ");
				month = sc.nextInt();
				if(month < 1 || month > 12) {
					System.out.println("Error, please enter a valid month.");
				}
			}while(month < 1 || month > 12);
			do {
				System.out.print("Enter day of hiring of "+ firstname+ " " + lastname + ": ");
				 day = sc.nextInt();
				 if(day < 1 || day > 31) {
					 System.out.println("Error, please enter a valid day.");
				 }
				
			}while(day < 1 || day > 31);
			 doh = new Date(checkDay(day,month,year),month, year);
			 
			 Employee p=new Employee(firstname,lastname,gender,dob,doh,"Cashier","Regular",salary,degree,yearsOfExp);
			 emp.addEmployee(cashList,p);
			 employeeWriter();
			 System.out.println("Regular cashier of name "+firstname+" "+lastname+" and id "+p.getId()+" has been added.");
			 mainMenu();
	}
	public static void addManagerCash()
	{
		String firstname,lastname, degree;
		char gender;
		Date dob,doh;
		double salary;
		int yearsOfExp;
		sc.nextLine();
		System.out.print("Enter cashier's first name: ");
		firstname=sc.nextLine();
		System.out.print("Enter cashier's last name: ");
		lastname=sc.nextLine();
		do {
			System.out.print("Enter cashier's degree(phd,master,bachelor,professor): ");
			degree=sc.nextLine();
			if(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")))
			{
				System.out.println("Error, please enter a valid degree.");
			}
		}while(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
				|| degree.equalsIgnoreCase("professor")));
		do {
			System.out.print("Enter salary for "+firstname+" "+lastname+": ");
			salary=sc.nextDouble();
			if(salary<=0)
			{
				System.out.println("Error, please enter a valid salary.");
			}
		}while(salary<=0);
		do {
			System.out.print("Enter years of experience for "+firstname+" "+lastname+": ");
			yearsOfExp=sc.nextInt();
			if(yearsOfExp<0)
			{
				System.out.println("Error, please enter a valid number of years.");
			}
		}while(yearsOfExp<0);
		sc.nextLine();
		do {
			System.out.print("Enter gender(M/F) of "+firstname+" "+lastname+": ");
			gender=sc.next().charAt(0);
			if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
			{
				System.out.println("Error, please enter a valid gender.");
			}
		}while(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'));
		int year, month, day;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
        LocalDateTime now = LocalDateTime.now();
		do {
			System.out.print("Enter year of birth of "+ firstname+ " " + lastname + ": ");
			year = sc.nextInt();
			if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
				System.out.println("Error, please enter a valid year.");
			}
		}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
		do {
			System.out.print("Enter month of birth of "+ firstname+ " " + lastname + ": ");
			month = sc.nextInt();
			if(month < 1 || month > 12) {
				System.out.println("Error, please enter a valid month.");
			}
		}while(month < 1 || month > 12);
		do {
			System.out.print("Enter day of birth of "+ firstname+ " " + lastname + ": ");
			 day = sc.nextInt();
			 if(day < 1 || day > 31) {
				 System.out.println("Error, please enter a valid day.");
			 }
			
		}while(day < 1 || day > 31);
		 dob = new Date(checkDay(day,month,year),month, year);
		 sc.nextLine();
		 
		 do {
				System.out.print("Enter year of hiring of "+ firstname+ " " + lastname + ": ");
				year = sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
					System.out.println("Error, please enter a valid year.");
				}
			}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
			do {
				System.out.print("Enter month of hiring of "+ firstname+ " " + lastname + ": ");
				month = sc.nextInt();
				if(month < 1 || month > 12) {
					System.out.println("Error, please enter a valid month.");
				}
			}while(month < 1 || month > 12);
			do {
				System.out.print("Enter day of hiring of "+ firstname+ " " + lastname + ": ");
				 day = sc.nextInt();
				 if(day < 1 || day > 31) {
					 System.out.println("Error, please enter a valid day.");
				 }
				
			}while(day < 1 || day > 31);
			 doh = new Date(checkDay(day,month,year),month, year);
			 
			 Employee p=new Employee(firstname,lastname,gender,dob,doh,"Cashier","Manager",salary,degree,yearsOfExp);
			 emp.addEmployee(cashList,p);
			 employeeWriter();
			 System.out.println("Manager Cashier of name "+firstname+" "+lastname+" and id "+p.getId()+" has been added.");
			 mainMenu();
	}
	public static void addRegularSkin()
	{
		String firstname,lastname, degree, position;
		char gender;
		Date dob,doh;
		double salary;
		int yearsOfExp;
		sc.nextLine();
		System.out.print("Enter skin care specialist's first name: ");
		firstname=sc.nextLine();
		System.out.print("Enter skin care specialist's last name: ");
		lastname=sc.nextLine();
		do {
			System.out.print("Enter skin care specialist's degree(phd,master,bachelor,professor): ");
			degree=sc.nextLine();
			if(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")))
			{
				System.out.println("Error, please enter a valid degree.");
			}
		}while(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
				|| degree.equalsIgnoreCase("professor")));
		do {
			System.out.print("Enter salary for "+firstname+" "+lastname+": ");
			salary=sc.nextDouble();
			if(salary<=0)
			{
				System.out.println("Error, please enter a valid salary.");
			}
		}while(salary<=0);
		do {
			System.out.print("Enter years of experience for "+firstname+" "+lastname+": ");
			yearsOfExp=sc.nextInt();
			if(yearsOfExp<0)
			{
				System.out.println("Error, please enter a valid number of years.");
			}
		}while(yearsOfExp<0);
		sc.nextLine();
		do {
			System.out.print("Enter gender(M/F) of "+firstname+" "+lastname+": ");
			gender=sc.next().charAt(0);
			if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
			{
				System.out.println("Error, please enter a valid gender.");
			}
		}while(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'));
		int year, month, day;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
        LocalDateTime now = LocalDateTime.now();
		do {
			System.out.print("Enter year of birth of "+ firstname+ " " + lastname + ": ");
			year = sc.nextInt();
			if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
				System.out.println("Error, please enter a valid year.");
			}
		}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
		do {
			System.out.print("Enter month of birth of "+ firstname+ " " + lastname + ": ");
			month = sc.nextInt();
			if(month < 1 || month > 12) {
				System.out.println("Error, please enter a valid month.");
			}
		}while(month < 1 || month > 12);
		do {
			System.out.print("Enter day of birth of "+ firstname+ " " + lastname + ": ");
			 day = sc.nextInt();
			 if(day < 1 || day > 31) {
				 System.out.println("Error, please enter a valid day.");
			 }
			
		}while(day < 1 || day > 31);
		 dob = new Date(checkDay(day,month,year),month, year);
		 sc.nextLine();
		 
		 do {
				System.out.print("Enter year of hiring of "+ firstname+ " " + lastname + ": ");
				year = sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
					System.out.println("Error, please enter a valid year.");
				}
			}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
			do {
				System.out.print("Enter month of hiring of "+ firstname+ " " + lastname + ": ");
				month = sc.nextInt();
				if(month < 1 || month > 12) {
					System.out.println("Error, please enter a valid month.");
				}
			}while(month < 1 || month > 12);
			do {
				System.out.print("Enter day of hiring of "+ firstname+ " " + lastname + ": ");
				 day = sc.nextInt();
				 if(day < 1 || day > 31) {
					 System.out.println("Error, please enter a valid day.");
				 }
				
			}while(day < 1 || day > 31);
			 doh = new Date(checkDay(day,month,year),month, year);
			 
			 Employee p=new Employee(firstname,lastname,gender,dob,doh,"Skin care specialist","Regular",
					 salary,degree,yearsOfExp);
			 emp.addEmployee(skinList,p);
			 employeeWriter();
			 System.out.println("Regular SkinCare specialist of name "+firstname+" "+lastname+" and id "+p.getId()+
					 " has been added.");
			 mainMenu();
	}
	public static void addManagerSkin()
	{
		String firstname,lastname, degree;
		char gender;
		Date dob,doh;
		double salary;
		int yearsOfExp;
		sc.nextLine();
		System.out.print("Enter skin care specialist's first name: ");
		firstname=sc.nextLine();
		System.out.print("Enter skin care specialist's last name: ");
		lastname=sc.nextLine();
		do {
			System.out.print("Enter skin care specialist's degree(phd,master,bachelor,professor): ");
			degree=sc.nextLine();
			if(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
					|| degree.equalsIgnoreCase("professor")))
			{
				System.out.println("Error, please enter a valid degree.");
			}
		}while(!(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
				|| degree.equalsIgnoreCase("professor")));
		do {
			System.out.print("Enter salary for "+firstname+" "+lastname+": ");
			salary=sc.nextDouble();
			if(salary<=0)
			{
				System.out.println("Error, please enter a valid salary.");
			}
		}while(salary<=0);
		do {
			System.out.print("Enter years of experience for "+firstname+" "+lastname+": ");
			yearsOfExp=sc.nextInt();
			if(yearsOfExp<0)
			{
				System.out.println("Error, please enter a valid number of years.");
			}
		}while(yearsOfExp<0);
		sc.nextLine();
		do {
			System.out.print("Enter gender(M/F) of "+firstname+" "+lastname+": ");
			gender=sc.next().charAt(0);
			if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
			{
				System.out.println("Error, please enter a valid gender.");
			}
		}while(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'));
		int year, month, day;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
        LocalDateTime now = LocalDateTime.now();
		do {
			System.out.print("Enter year of birth of "+ firstname+ " " + lastname + ": ");
			year = sc.nextInt();
			if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
				System.out.println("Error, please enter a valid year.");
			}
		}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
		do {
			System.out.print("Enter month of birth of "+ firstname+ " " + lastname + ": ");
			month = sc.nextInt();
			if(month < 1 || month > 12) {
				System.out.println("Error, please enter a valid month.");
			}
		}while(month < 1 || month > 12);
		do {
			System.out.print("Enter day of birth of "+ firstname+ " " + lastname + ": ");
			 day = sc.nextInt();
			 if(day < 1 || day > 31) {
				 System.out.println("Error, please enter a valid day.");
			 }
			
		}while(day < 1 || day > 31);
		 dob = new Date(checkDay(day,month,year),month, year);
		 sc.nextLine();
		 
		 do {
				System.out.print("Enter year of hiring of "+ firstname+ " " + lastname + ": ");
				year = sc.nextInt();
				if(year<1900 || year>Integer.parseInt(dtf.format(now))) {
					System.out.println("Error, please enter a valid year.");
				}
			}while(year<1900 || year>Integer.parseInt(dtf.format(now)));
			do {
				System.out.print("Enter month of hiring of "+ firstname+ " " + lastname + ": ");
				month = sc.nextInt();
				if(month < 1 || month > 12) {
					System.out.println("Error, please enter a valid month.");
				}
			}while(month < 1 || month > 12);
			do {
				System.out.print("Enter day of hiring of "+ firstname+ " " + lastname + ": ");
				 day = sc.nextInt();
				 if(day < 1 || day > 31) {
					 System.out.println("Error, please enter a valid day.");
				 }
				
			}while(day < 1 || day > 31);
			 doh = new Date(checkDay(day,month,year),month, year);
			 
			 Employee p=new Employee(firstname,lastname,gender,dob,doh,"Skin care specialist","Manager",salary,degree,yearsOfExp);
			 emp.addEmployee(skinList,p);
			 employeeWriter();
			 System.out.println("Manager SkinCare specialist of name "+firstname+" "+lastname+" and id "+p.getId()+
					 " has been added.");
			 mainMenu();
	}
	public static boolean checkLeapYear(int year) {
		if((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0)) {
			return true;
		}
		return false;
	}
	public static int checkDay(int day, int month, int year) {
		
		 
			switch(month) {
			
			case 1:
	        case 3:
	        case 5:
	        case 7:
	        case 8:
	        case 10:
	        case 12:
	        	if(day>=1 && day<=31) {
	        		return day;
	        	} 
	        		
	        		
	        	break;
	        case 4:
	        case 6:
	        case 9:
	        case 11:
	        	if(day>=1 && day<=30) {
	        		return day;
			} 
	        	else if(day == 31) {
	        		day = 30;
	        		return day;
			}
	        	break;
	        case 2:
	        	if(checkLeapYear(year))
	        	{
	        		if(day>=1 && day<=29)
	        		{
	        			return day;
	        		}
	        		else if(day == 30 || day == 31) 
	        		{
	        			day = 29;
	        			return day;
	        		}
	        	}
	        	else 
	        	{
	        		if(day>=1 && day<=28)
	        		{
	        			return day;
	        		} 
	        		else if(day == 29 || day == 30 || day == 31) {
	        			day = 28;
	        			return day;
	        		}
	        	}
	        	break;
			}
			return day;
		
	}
	
	public static void addEmployee()
	{
		System.out.print("1)Add Pharma\n2)Add Cashier\n3)Add SkinCare Specialist\n4)Go back\n");
		do {
			System.out.print("Enter here: ");
			choice = sc.nextInt();
			if(choice < 1 || choice > 4) {
				System.out.println("Error ! Invalid choice please enter again");
			}
		}while(choice < 1 || choice > 4);
		switch(choice) {
		case 1: addPharmaEmployee();
			break;
		case 2: addCashEmployee();
		break;
		case 3: addSkinEmployee();
		break;
		case 4: aboutEmployees();
		break;
		
		}
		
	}
	public static void manageEmployee()
	{
		System.out.print("1)Manage Pharma\n2)Manage Cashier\n3)Manage SkinCare Specialist\n4)Go back\n");
		do {
			System.out.print("Enter here: ");
			choice = sc.nextInt();
			if(choice < 1 || choice > 4) {
				System.out.println("Error ! Invalid choice please enter again");
			}
		}while(choice < 1 || choice > 4);
		switch(choice) {
		case 1: managePharmaEmployee();
			break;
		case 2: manageCashEmployee();
		break;
		case 3: manageSkinEmployee();
		break;
		case 4: aboutEmployees();
		break;
		
		}
		
	}
	public static void displayEmployee()
	{
		
	System.out.print("1)Display Pharma Employees\n2)Display Cashier Employees\n3)Display SkinCare Specialist Employees\n"
			+ "4)Display all Employees\n5)Go back\n");
	do {
		System.out.print("Enter here: ");
		choice = sc.nextInt();
		if(choice < 1 || choice > 5) {
			System.out.println("Error ! Invalid choice please enter again");
		}
	}while(choice < 1 || choice > 5);
	switch(choice) {
	case 1: displayPharmaEmployee();
		break;
	case 2: displayCashEmployee();
		break;
	case 3: displaySkinEmployee();
		break;
	case 4: displayAllEmployee();
		break;
	case 5: aboutEmployees();
		break;
	}
		
		
		
		
		
	}
	public static void searchEmployee()
	{
		System.out.print("1)Search For Pharma\n2)Search For Cashier\n3)Search For SkinCare Specialist\n4)Go back\n");
		do {
			System.out.print("Enter here: ");
			choice = sc.nextInt();
			if(choice < 1 || choice > 4) {
				System.out.println("Error ! Invalid choice please enter again");
			}
		}while(choice < 1 || choice > 4);
		switch(choice) {
		case 1: searchForPharmaEmployee();
			break;
		case 2: searchForCashEmployee();
			break;
		case 3: searchForSkinEmployee();
			break;
		case 4: aboutEmployees();
			break;
		
		}
	}
	public static void searchForPharmaEmployee()
	{
		String fname,lname;
		sc.nextLine();
		System.out.print("Enter the first name of required pharma: ");
		fname=sc.nextLine();
		System.out.print("Enter the last name of required pharma: ");
		lname=sc.nextLine();
		emp.searchForEmployee(pharmaList, fname, lname, "Pharma");
		do {
			System.out.print("\nEnter 1 to go back to main menu:");
			choice=sc.nextInt();
			if(choice!=1)
			{
				System.out.print("Invalid entry.");
			}
			}while(choice!=1);
			if(choice==1)
			{
				mainMenu();
			}
		
		
		
	}
	public static void searchForCashEmployee()
	{
		String fname,lname;
		sc.nextLine();
		System.out.print("Enter the first name of required cashier: ");
		fname=sc.nextLine();
		System.out.print("Enter the last name of required cashier: ");
		lname=sc.nextLine();
		emp.searchForEmployee(cashList, fname, lname, "cashier");
		do {
			System.out.print("\nEnter 1 to go back to main menu:");
			choice=sc.nextInt();
			if(choice!=1)
			{
				System.out.print("Invalid entry.");
			}
			}while(choice!=1);
			if(choice==1)
			{
				mainMenu();
			}
	}
	public static void searchForSkinEmployee()
	{
		String fname,lname;
		sc.nextLine();
		System.out.print("Enter the first name of required skin care specialist: ");
		fname=sc.nextLine();
		System.out.print("Enter the last name of required skin care specialist: ");
		lname=sc.nextLine();
		emp.searchForEmployee(skinList, fname, lname, "skin care specialist");
		do {
			System.out.print("\nEnter 1 to go back to main menu:");
			choice=sc.nextInt();
			if(choice!=1)
			{
				System.out.print("Invalid entry.");
			}
			}while(choice!=1);
			if(choice==1)
			{
				mainMenu();
			}
	}
	//////////////////////////////////////
	public static void aboutEmployees()
	{
		
		System.out.print("1)Add Employee\n2)Remove Employee\n3)Manage Employees\n4)Display Employees\n5)Search For Employee\n"
				+ "6)GoBack\n");
		do {
			System.out.print("Enter Here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>6)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>6);
		switch(choice)
		{
		case 1:
			addEmployee();
			break;
		case 2:
			removeEmployee();
			break;
		case 3:
			manageEmployee();
			break;
		case 4:
			displayEmployee();
			break;
		case 5:
			searchEmployee();
			break;
		case 6:
			mainMenu();
			break;
		}
	}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void searchForMedicine()
	{
		sc.nextLine();
		String medicineName;
		System.out.print("Enter the medicine's name: ");
		medicineName=sc.nextLine();
		med.searchForMedicine(medicineList, medicineName);
		do {
			System.out.print("\nEnter 1 to go back to main menu:");
			choice=sc.nextInt();
			if(choice!=1)
			{
				System.out.print("Invalid entry.");
			}
			}while(choice!=1);
			if(choice==1)
			{
				mainMenu();
			}
	}
	public static void searchForSkinProduct()
	{
		sc.nextLine();
		String skinName;
		System.out.print("Enter the skin care product's name: ");
		skinName=sc.nextLine();
		skinProduct.searchForSkin(skinProductsList, skinName);
		do {
			System.out.print("\nEnter 1 to go back to main menu:");
			choice=sc.nextInt();
			if(choice!=1)
			{
				System.out.print("Invalid entry.");
			}
			}while(choice!=1);
			if(choice==1)
			{
				mainMenu();
			}
	}
	 
	public static void displayMedicines()
	{
		med.printMedicines(medicineList);
		do {
            System.out.print("\nEnter 1 to go back to main menu:");
            choice=sc.nextInt();
            if(choice!=1)
            {
                System.out.print("Invalid entry.");
            }
            }while(choice!=1);
            if(choice==1)
            {
                mainMenu();
            }
	}
	public static void  displaySkinProducts()
	{
		skinProduct.printSkin(skinProductsList);
		do {
            System.out.print("\nEnter 1 to go back to main menu:");
            choice=sc.nextInt();
            if(choice!=1)
            {
                System.out.print("Invalid entry.");
            }
            }while(choice!=1);
            if(choice==1)
            {
                mainMenu();
            }
	}
	 
	public static void displayAllProducts()
	{
		med.printMedicines(medicineList);
		skinProduct.printSkin(skinProductsList);
		do {
            System.out.print("\nEnter 1 to go back to main menu:");
            choice=sc.nextInt();
            if(choice!=1)
            {
                System.out.print("Invalid entry.");
            }
            }while(choice!=1);
            if(choice==1)
            {
                mainMenu();
            }
	}
	public static void manageMedicine()
	{
		int medicineChoice,yearProduce=2020,yearExpire,monthProduce,monthExpire;
		String medicineName,ingredients,answer;
		Date produceDate,expireDate;
		double price=10,wholeSalePrice;
		boolean requirePrescription;
		for(int i=0;i<medicineList.size();i++)
		{
			System.out.println((i+1)+"-"+" Medicine Name: "+medicineList.get(i).getName());
		}
		System.out.println((medicineList.size()+1)+"- GoBack");
		do {
			System.out.print("Enter Here: ");
			medicineChoice=sc.nextInt();
			if(medicineChoice<1 || medicineChoice>(medicineList.size()+1))
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(medicineChoice<1 || medicineChoice>(medicineList.size()+1));
		
		if(medicineChoice<(medicineList.size()+1))
		{
		System.out.print("1)Edit Medicine's Name\n"
						+"2)Edit Medicine's Ingredients\n"
						+ "3)Edit Medicine's Production Date\n"
						+ "4)Edit Medicine's Expiry Date\n"
						+"5)Edit Medicine's Price\n"
						+"6)Edit Medicine's WholeSalePrice\n"
						+"7)Edit Medicine's required prescription\n"
						+ "8)GoBack");
		do {
			System.out.print("Enter Here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>8)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>8);
		switch(choice)
		{
		case 1:
			sc.nextLine();
			System.out.print("Enter new name for "+medicineList.get(medicineChoice-1).getName()+" : ");
			medicineName=sc.nextLine();
			medicineList.get(medicineChoice-1).setName(medicineName);
			medicineWriter();
			System.out.println("Medicine's name is changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 2:
			sc.nextLine();
			System.out.print("Enter new ingredients for "+medicineList.get(medicineChoice-1).getName()+" : ");
			ingredients=sc.nextLine();
			medicineList.get(medicineChoice-1).setIngredients(ingredients);
			medicineWriter();
			System.out.println("Medicine's ingredients are changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 3:
			do {
				System.out.print("Enter new year of production for "+medicineList.get(medicineChoice-1).getName()
						+" : ");
				yearProduce=sc.nextInt();
				if(yearProduce<2000 || yearProduce>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.println("Invalid date of production please enter again.");
				}
			}while(yearProduce<2000 || yearProduce>Integer.parseInt(dtf.format(now_Year)));
			do {
				System.out.print("Enter new month of production for "+medicineList.get(medicineChoice-1).getName()
						+" : ");
				monthProduce=sc.nextInt();
				if(monthProduce<1 || monthProduce>12)
				{
					System.out.println("Error invalid month please enter again.");
				}
			}while(monthProduce<1 || monthProduce>12);
			produceDate=new Date(monthProduce,yearProduce);
			medicineList.get(medicineChoice-1).setProduceDate(produceDate);
			medicineWriter();
			System.out.println("Medicine's produceDate is changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 4:
			do {
					System.out.print("Enter new year of expiry for "+medicineList.get(medicineChoice-1).getName()
							+" : ");
					yearExpire=sc.nextInt();
					if(yearExpire<2000 || yearExpire>Integer.parseInt(dtf.format(now_Year))+15)
					{
						System.out.println("Invalid date of production please enter again.");
					}
				}while(yearExpire<2000 || yearExpire>Integer.parseInt(dtf.format(now_Year))+15);
			do {
					System.out.print("Enter new month of expiry for "+medicineList.get(medicineChoice-1).getName()
							+" : ");
					monthExpire=sc.nextInt();
					if(monthExpire<1 || monthExpire>12)
					{
						System.out.println("Error invalid month please enter again.");
					}
				}while(monthExpire<1 || monthExpire>12);
				expireDate=new Date(monthExpire,yearExpire);
				medicineList.get(medicineChoice-1).setExpireDate(expireDate);
				medicineWriter();
				System.out.println("Medicine's ExpiryDate is changed successfully.");
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;
		case 5:	
			do {
				System.out.print("Enter new price for "+medicineList.get(medicineChoice-1).getName()
						+" : ");
				price=sc.nextDouble();
				if(price<0)
				{
					System.out.println("Error, Invalid price please enter again.");
				}
			}while(price<0);
			medicineList.get(medicineChoice-1).setPrice(price);
			medicineWriter();
			System.out.println("Medicine's price is changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 6:
			do {
				System.out.print("Enter new wholeSalePrice for "+medicineList.get(medicineChoice-1).getName()
						+" : ");
				wholeSalePrice=sc.nextDouble();
				if(wholeSalePrice<0 || wholeSalePrice>medicineList.get(medicineChoice-1).getWholeSalePrice())
				{
					System.out.println("Error, Invalid price please enter again.");
				}
			}while(wholeSalePrice<0 || wholeSalePrice>medicineList.get(medicineChoice-1).getWholeSalePrice());
			medicineList.get(medicineChoice-1).setWholeSalePrice(wholeSalePrice);
			medicineWriter();
			System.out.println("Medicine's whole sale price is changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 7:
			sc.nextLine();
			System.out.println("Does this medicine require prescription from the doctor ?(Yes/No)");
			do {
				System.out.print("Enter Here: ");
				answer=sc.nextLine();
				if(!(answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("no")))
				{
					System.out.println("Error, Invalid answer please enter yes or no.");
				}
			}while(!(answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("no")));
			
			if(answer.equalsIgnoreCase("yes"))
			{
				requirePrescription=true;
			}
			else
			{
				requirePrescription=false;
			}
			medicineList.get(medicineChoice-1).setRequirePrescription(requirePrescription);
			medicineWriter();
			System.out.println("Medicine's requiry for prescription is changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			
			break;
		case 8:
			manageMedicine();
			break;
			
		}
	}
		else
		{
			manageProduct();
		}
}
	public static void  manageSkinProduct()
	{

		int skinChoice,yearProduce=2020,yearExpire,monthProduce,monthExpire;
		String skinName,ingredients,answer;
		Date produceDate,expireDate;
		double price=10,wholeSalePrice;
		boolean requirePrescription;
		for(int i=0;i<medicineList.size();i++)
		{
			System.out.println((i+1)+"-"+" Medicine Name: "+medicineList.get(i).getName());
		}
		System.out.println((medicineList.size()+1)+"- GoBack");
		do {
			System.out.print("Enter Here: ");
			skinChoice=sc.nextInt();
			if(skinChoice<1 || skinChoice>(medicineList.size()+1))
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(skinChoice<1 || skinChoice>(medicineList.size()+1));
		
		if(skinChoice<(medicineList.size()+1))
		{
		System.out.print("1)Edit Medicine's Name\n"
						+"2)Edit Medicine's Ingredients\n"
						+ "3)Edit Medicine's Production Date\n"
						+ "4)Edit Medicine's Expiry Date\n"
						+"5)Edit Medicine's Price\n"
						+"6)Edit Medicine's WholeSalePrice\n"
						+"7)GoBack\n");
		do {
			System.out.print("Enter Here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>7)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>7);
		switch(choice)
		{
		case 1:
			sc.nextLine();
			System.out.print("Enter new name for "+medicineList.get(skinChoice-1).getName()+" : ");
			skinName=sc.nextLine();
			skinProductsList.get(skinChoice-1).setName(skinName);
			skinWriter();
			System.out.println("Medicine's name is changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 2:
			sc.nextLine();
			System.out.print("Enter new ingredients for "+skinProductsList.get(skinChoice-1).getName()+" : ");
			ingredients=sc.nextLine();
			skinProductsList.get(skinChoice-1).setIngredients(ingredients);
			skinWriter();
			System.out.println("Skin product's ingredients are changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 3:
			do {
				System.out.print("Enter new year of production for "+skinProductsList.get(skinChoice-1).getName()
						+" : ");
				yearProduce=sc.nextInt();
				if(yearProduce<2000 || yearProduce>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.println("Invalid date of production please enter again.");
				}
			}while(yearProduce<2000 || yearProduce>Integer.parseInt(dtf.format(now_Year)));
			do {
				System.out.print("Enter new month of production for "+skinProductsList.get(skinChoice-1).getName()
						+" : ");
				monthProduce=sc.nextInt();
				if(monthProduce<1 || monthProduce>12)
				{
					System.out.println("Error invalid month please enter again.");
				}
			}while(monthProduce<1 || monthProduce>12);
			produceDate=new Date(monthProduce,yearProduce);
			skinProductsList.get(skinChoice-1).setProduceDate(produceDate);
			skinWriter();
			System.out.println("Medicine's produceDate is changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 4:
			do {
					System.out.print("Enter new year of expiry for "+skinProductsList.get(skinChoice-1).getName()
							+" : ");
					yearExpire=sc.nextInt();
					if(yearExpire<2000 || yearExpire>Integer.parseInt(dtf.format(now_Year))+15)
					{
						System.out.println("Invalid date of production please enter again.");
					}
				}while(yearExpire<2000 || yearExpire>Integer.parseInt(dtf.format(now_Year))+15);
			do {
					System.out.print("Enter new month of expiry for "+skinProductsList.get(skinChoice-1).getName()
							+" : ");
					monthExpire=sc.nextInt();
					if(monthExpire<1 || monthExpire>12)
					{
						System.out.println("Error invalid month please enter again.");
					}
				}while(monthExpire<1 || monthExpire>12);
				expireDate=new Date(monthExpire,yearExpire);
				skinProductsList.get(skinChoice-1).setExpireDate(expireDate);
				skinWriter();
				System.out.println("Medicine's ExpiryDate is changed successfully.");
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				break;
		case 5:	
			do {
				System.out.print("Enter new price for "+skinProductsList.get(skinChoice-1).getName()
						+" : ");
				price=sc.nextDouble();
				if(price<0)
				{
					System.out.println("Error, Invalid price please enter again.");
				}
			}while(price<0);
			skinProductsList.get(skinChoice-1).setPrice(price);
			skinWriter();
			System.out.println("Medicine's price is changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 6:
			do {
				System.out.print("Enter new wholeSalePrice for "+skinProductsList.get(skinChoice-1).getName()
						+" : ");
				wholeSalePrice=sc.nextDouble();
				if(wholeSalePrice<0 || wholeSalePrice>skinProductsList.get(skinChoice-1).getWholeSalePrice())
				{
					System.out.println("Error, Invalid price please enter again.");
				}
			}while(wholeSalePrice<0 || wholeSalePrice>skinProductsList.get(skinChoice-1).getWholeSalePrice());
			skinProductsList.get(skinChoice-1).setWholeSalePrice(wholeSalePrice);
			skinWriter();
			System.out.println("Skin care product's whole sale price is changed successfully.");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 7:
			manageSkinProduct();
		}
	}
		else
		{
			manageProduct();
		}
	}
	 
	public static void removeMedicine()
	{
		for(int i=0;i<medicineList.size();i++)
		{
			System.out.println((i+1)+"-"+" Name: "+medicineList.get(i).getName());
		}
		System.out.println((medicineList.size()+1)+"- GoBack");
		System.out.println("Which medicine do you want to remove ?");
		do {
		System.out.print("\nEnter Here: ");
		choice=sc.nextInt();
		if(choice<1 || choice>medicineList.size()+1)
		{
			System.out.println("Please enter a number between 1 and "+(medicineList.size()+1)+".");
		}
		}while(choice<1 || choice>medicineList.size()+1);
		if(choice==medicineList.size()+1)
		{
			aboutProducts();
		}
		else
		{
			System.out.println("Medicine of name "+medicineList.get(choice-1).getName()+" has been removed.");
			med.removeMedicine(medicineList,choice);
			skinWriter();
			mainMenu();
		}
		
	}
	public static void removeSkinProduct()
	{
		for(int i=0;i<medicineList.size();i++)
		{
			System.out.println((i+1)+"-"+" Name: "+skinProductsList.get(i).getName());
		}
		System.out.println((skinProductsList.size()+1)+"- GoBack");
		System.out.println("Which skin care product do you want to remove ?");
		do {
		System.out.print("\nEnter Here: ");
		choice=sc.nextInt();
		if(choice<1 || choice>skinProductsList.size()+1)
		{
			System.out.println("Please enter a number between 1 and "+(skinProductsList.size()+1)+".");
		}
		}while(choice<1 || choice>skinProductsList.size()+1);
		if(choice==skinProductsList.size()+1)
		{
			aboutProducts();
		}
		else
		{
			System.out.println("skin care product of name "+skinProductsList.get(choice-1).getName()+" has been removed.");
			skinProduct.removeSkin(skinProductsList,choice);
			skinWriter();
			mainMenu();
		}
	}
	 
	public static void addMedicine()
	{
		
		sc.nextLine();
		String medicineName,ingredients,type,sideEffect,answer;
		Date produceDate,expireDate;
		int yearProduce,yearExpire,monthProduce,monthExpire,enterQty,stockQty;
		String fname,lname,addressAgent,addressComp,cname,country;
		double price,wholeSalePrice;
		boolean requirePrescription;
		boolean alreadyExists=false;
		
		System.out.print("Enter medicine Name:");
		medicineName=sc.nextLine();
		for(int i=0;i<medicineList.size();i++)
		{
			if(medicineList.get(i).getName().equalsIgnoreCase(medicineName))
			{
				alreadyExists=true;
			}
		}
		if(alreadyExists==false)
		{
			do {
			System.out.print("Enter medicine type(Liquid/Tablets/Capsules/Injections/Imhalers/Implants/Drops):");
			type=sc.nextLine();
			if(!(type.equalsIgnoreCase("Liquid") || type.equalsIgnoreCase("Tablets") ||
	                type.equalsIgnoreCase("Capsules") || type.equalsIgnoreCase("Injections") || type.equalsIgnoreCase("Inhalers")
	                 || type.equalsIgnoreCase("Implants") || type.equalsIgnoreCase("Drops")))
			{
				System.out.println("Error, Invalid type please enter again.");
			}
			}while(!(type.equalsIgnoreCase("Liquid") || type.equalsIgnoreCase("Tablets") ||
	                type.equalsIgnoreCase("Capsules") || type.equalsIgnoreCase("Injections") || type.equalsIgnoreCase("Inhalers")
	                 || type.equalsIgnoreCase("Implants") || type.equalsIgnoreCase("Drops")));
			
			System.out.print("Enter medicine ingredients:");
			ingredients=sc.nextLine();
			do {
				System.out.print("Enter year of production:");
				yearProduce=sc.nextInt();
				if(yearProduce<2000 || yearProduce>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.println("Invalid date of production please enter again.");
				}
			}while(yearProduce<2000 || yearProduce>Integer.parseInt(dtf.format(now_Year)));
			do {
				System.out.print("Enter month of production:");
				monthProduce=sc.nextInt();
				if(monthProduce<1 || monthProduce>12)
				{
					System.out.println("Error invalid month please enter again.");
				}
			}while(monthProduce<1 || monthProduce>12);
			produceDate=new Date(monthProduce,yearProduce);
			
			do {
					System.out.print("Enter year of expiry:");
					yearExpire=sc.nextInt();
					if(yearExpire<yearProduce || yearExpire>Integer.parseInt(dtf.format(now_Year))+15)
					{
						System.out.println("Invalid date of production please enter again.");
					}
				}while(yearExpire<yearProduce || yearExpire>Integer.parseInt(dtf.format(now_Year))+15);
			do {
					System.out.print("Enter month of expiry:");
					monthExpire=sc.nextInt();
					if(monthExpire<1 || monthExpire>12)
					{
						System.out.println("Error invalid month please enter again.");
					}
				}while(monthExpire<1 || monthExpire>12);
				expireDate=new Date(monthExpire,yearExpire);
				
			do {
				System.out.print("Enter the medicine's price: ");
				price=sc.nextDouble();
				if(price<0)
				{
					System.out.println("Error, Invalid price please enter again.");
				}
			}while(price<0);
			
			do {
				System.out.print("Enter the medicine's wholeSalePrice: ");
				wholeSalePrice=sc.nextDouble();
				if(wholeSalePrice<0 || wholeSalePrice>price)
				{
					System.out.println("Error, Invalid price please enter again.");
				}
			}while(wholeSalePrice<0 || wholeSalePrice>price);
			sc.nextLine();
			System.out.println("Does this medicine require prescription from the doctor ?(Yes/No)");
			do {
				System.out.print("Enter Here: ");
				answer=sc.nextLine();
				if(!(answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("no")))
				{
					System.out.println("Error, Invalid answer please enter yes or no.");
				}
			}while(!(answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("no")));
			
			if(answer.equalsIgnoreCase("yes"))
			{
				requirePrescription=true;
			}
			else
			{
				requirePrescription=false;
			}
			
			med=new Medicine(medicineName,produceDate,expireDate,ingredients,price,wholeSalePrice,requirePrescription,
					type);
			med.addMedicine(medicineList,med);
			medicineWriter();
		
			System.out.println("Medicine of name "+medicineName+" is successfulyy added.");
			System.out.println("Would you like to add quantity for this medicine right now?");
			do {
				System.out.print("1)Yes\n2)No\n");
				System.out.print("Enter Here: ");
				enterQty=sc.nextInt();
				if(enterQty<1 || enterQty>2)
				{
					System.out.println("Error, Invalid entry please enter 1 or 2.");
				}
			}while(enterQty<1 || enterQty>2);
			switch(enterQty)
			{
			case 1:
				do {
					System.out.print("Enter quantity:");
					stockQty=sc.nextInt();
					if(stockQty<=0)
					{
						System.out.println("Error, Invalid quantity please enter again.");
					}
				}while(stockQty<=0);
				medicineStock=new MedicineStock(med.getName(),stockQty);
				medicineQuantityList.add(medicineStock.getQuantity());
				StockMedicineWriter();
				break;
			case 2:
				stockQty=0;
				medicineStock=new MedicineStock(med.getName(),stockQty);
				medicineQuantityList.add(medicineStock.getQuantity());
				StockMedicineWriter();
				break;
			}
			do {
				System.out.print("\nEnter 1 to go back to main menu:");
				choice=sc.nextInt();
				if(choice!=1)
				{
					System.out.print("Invalid entry.");
				}
				}while(choice!=1);
				if(choice==1)
				{
					mainMenu();
				}
		}
		else
		{
			System.out.println("The medicine of name "+medicineName+" already exists!");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
	            
		}
	}
	public static void addSkinProduct()
	{
		sc.nextLine();
		String skinName,ingredients,category;
		Date produceDate,expireDate;
		int yearProduce,yearExpire,monthProduce,monthExpire,enterQty,stockQty;
		String fname,lname,addressAgent,addressComp,cname,country,answer;
		double price,wholeSalePrice;
		boolean naturalOrChemical;
		boolean alreadyExists=false;
		
		System.out.print("Enter skin care product Name:");
		skinName=sc.nextLine();
		for(int i=0;i<skinProductsList.size();i++)
		{
			if(skinProductsList.get(i).getName().equalsIgnoreCase(skinName))
			{
				alreadyExists=true;
			}
		}
		if(alreadyExists==false)
		{
			do {
			System.out.print("Enter skin care product category(Serum/moisturizer/exfoliator/Body Lotion/Eye Cream):");
			category=sc.nextLine();
			if(!(category.equalsIgnoreCase("Serum") || category.equalsIgnoreCase("moisturizer") ||
					category.equalsIgnoreCase("exfoliator") || category.equalsIgnoreCase("Body Lotion")
	                 || category.equalsIgnoreCase("Eye Cream")))
			{
				System.out.println("Error, Invalid type please enter again.");
			}
			}while(!(category.equalsIgnoreCase("Serum") || category.equalsIgnoreCase("moisturizer") ||
					category.equalsIgnoreCase("exfoliator") || category.equalsIgnoreCase("Body Lotion")
	                || category.equalsIgnoreCase("Eye Cream")));
			
			System.out.print("Enter skin care product ingredients:");
			ingredients=sc.nextLine();
			do {
				System.out.print("Enter year of production:");
				yearProduce=sc.nextInt();
				if(yearProduce<2000 || yearProduce>Integer.parseInt(dtf.format(now_Year)))
				{
					System.out.println("Invalid date of production please enter again.");
				}
			}while(yearProduce<2000 || yearProduce>Integer.parseInt(dtf.format(now_Year)));
			do {
				System.out.print("Enter month of production:");
				monthProduce=sc.nextInt();
				if(monthProduce<1 || monthProduce>12)
				{
					System.out.println("Error invalid month please enter again.");
				}
			}while(monthProduce<1 || monthProduce>12);
			produceDate=new Date(monthProduce,yearProduce);
			
			do {
					System.out.print("Enter year of expiry:");
					yearExpire=sc.nextInt();
					if(yearExpire<yearProduce || yearExpire>Integer.parseInt(dtf.format(now_Year))+15)
					{
						System.out.println("Invalid date of production please enter again.");
					}
				}while(yearExpire<yearProduce || yearExpire>Integer.parseInt(dtf.format(now_Year))+15);
			do {
					System.out.print("Enter month of expiry:");
					monthExpire=sc.nextInt();
					if(monthExpire<1 || monthExpire>12)
					{
						System.out.println("Error invalid month please enter again.");
					}
				}while(monthExpire<1 || monthExpire>12);
				expireDate=new Date(monthExpire,yearExpire);
				
			do {
				System.out.print("Enter the skin care product's price: ");
				price=sc.nextDouble();
				if(price<0)
				{
					System.out.println("Error, Invalid price please enter again.");
				}
			}while(price<0);
			
			do {
				System.out.print("Enter the skin care product's wholeSalePrice: ");
				wholeSalePrice=sc.nextDouble();
				if(wholeSalePrice<0 || wholeSalePrice>price)
				{
					System.out.println("Error, Invalid price please enter again.");
				}
			}while(wholeSalePrice<0 || wholeSalePrice>price);
			 
				sc.nextLine();
			
			System.out.println("Is this skin product natural or chemical ?(Natural/Chemical)");
			do {
				System.out.print("Enter Here: ");
				answer=sc.nextLine();
				if(!(answer.equalsIgnoreCase("Natural") || answer.equalsIgnoreCase("Chemical")))
				{
					System.out.println("Error, Invalid answer please enter Natural or Chemical.");
				}
			}while(!(answer.equalsIgnoreCase("Natural") || answer.equalsIgnoreCase("Chemical")));
			
			if(answer.equalsIgnoreCase("Natural"))
			{
				naturalOrChemical=true;
			}
			else
			{
				naturalOrChemical=false;
			}
			
			skinProduct=new SkinCareProducts(skinName,produceDate,expireDate,ingredients,price,wholeSalePrice,
					 naturalOrChemical, category);
			skinProduct.addSkin(skinProductsList, skinProduct);
			skinWriter();
			System.out.println("skin care product of name "+skinName+" is successfulyy added.");
			System.out.println("Would you like to add quantity for this product right now?");
			do {
				System.out.print("1)Yes\n2)No\n");
				System.out.print("Enter Here: ");
				enterQty=sc.nextInt();
				if(enterQty<1 || enterQty>2)
				{
					System.out.println("Error, Invalid entry please enter 1 or 2.");
				}
			}while(enterQty<1 || enterQty>2);
			switch(enterQty)
			{
			case 1:
				do {
					System.out.print("Enter quantity:");
					stockQty=sc.nextInt();
					if(stockQty<=0)
					{
						System.out.println("Error, Invalid quantity please enter again.");
					}
				}while(stockQty<=0);
				skinQuantityList.add(stockQty);
				break;
			case 2:
				skinQuantityList.add(0);
				break;
			}
			skinStock.inStock(skinProductsList, skinQuantityList,skinInStock);
			skinStock.outStock(skinProductsList, skinQuantityList,skinOutStock);
			do {
				System.out.print("\nEnter 1 to go back to main menu:");
				choice=sc.nextInt();
				if(choice!=1)
				{
					System.out.print("Invalid entry.");
				}
				}while(choice!=1);
				if(choice==1)
				{
					mainMenu();
				}
			}
		else
		{
			System.out.println("The skin care product of name "+skinName+" already exists!");
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
	            
		}
	
	
}
	 
	public static void addProduct()
	{
		System.out.print("1)Add Medicine\n2)Add Skin care Product\n3)Go back\n");
		do {
			System.out.print("Enter here: ");
			choice = sc.nextInt();
			if(choice < 1 || choice > 3) {
				System.out.println("Error ! Invalid choice please enter again");
			}
		}while(choice < 1 || choice > 3);
		switch(choice) {
		case 1: addMedicine();
			break;
		case 2: addSkinProduct();
		break;
		case 3: aboutProducts();
		break;
		}
		
	}
	public static void removeProduct()
	{
		System.out.print("1)Remove Medicine\n2)Remove Skin care Product\n3)Go back\n");
		do {
			System.out.print("Enter here: ");
			choice = sc.nextInt();
			if(choice < 1 || choice > 3) {
				System.out.println("Error ! Invalid choice please enter again");
			}
		}while(choice < 1 || choice > 3);
		switch(choice) {
		case 1: removeMedicine();
			break;
		case 2: removeSkinProduct();
			break;
		case 3: aboutProducts();
			break;
		}
	}
	public static void manageProduct()
	{
		System.out.print("1)Manage Medicine\n2)Manage Skin Care Product\n3)Go back\n");
		do {
			System.out.print("Enter here: ");
			choice = sc.nextInt();
			if(choice < 1 || choice > 3) {
				System.out.println("Error ! Invalid choice please enter again");
			}
		}while(choice < 1 || choice > 3);
		switch(choice) {
		case 1: manageMedicine();
			break;
		case 2: manageSkinProduct();
			break;
		case 3: aboutProducts();
			break;
		}
		
	}
	public static void displayProduct()
	{
		
	System.out.print("1)Display All Medicines\n2)Display All Skin Care Products\n3)Display all Products\n4)Go back\n");
	do {
		System.out.print("Enter here: ");
		choice = sc.nextInt();
		if(choice < 1 || choice > 4) {
			System.out.println("Error ! Invalid choice please enter again");
		}
	}while(choice < 1 || choice > 4);
	switch(choice) {
	case 1: displayMedicines();
		break;
	case 2: displaySkinProducts();
		break;
	case 3: displayAllProducts();
		break;
	case 4: aboutProducts();
		break;
	}
		
	}
	public static void searchProduct()
	{
		System.out.print("1)Search For Medicine\n2)Search For  Skin Care Product\n3)Go back\n");
		do {
			System.out.print("Enter here: ");
			choice = sc.nextInt();
			if(choice < 1 || choice > 3) {
				System.out.println("Error ! Invalid choice please enter again");
			}
		}while(choice < 1 || choice > 3);
		switch(choice) {
		case 1: searchForMedicine();
			break;
		case 2: searchForSkinProduct();
			break;
		case 3: aboutProducts();
			break;
		
		}
	}
	
	public static void checkStockMedicine() {
		int quantity;
		System.out.print("1)Add Quantity For a Medicine\n2)Reduce Quantity For a Medicine\n3)Print Medicines Stock\n"
				+ "4)GoBack\n");
		do {
			System.out.print("Enter Here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>4)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>4);
		switch(choice)
		{
		case 1:
			for(int i=0;i<medicineList.size();i++)
			{
				System.out.println((i+1)+"-"+" Medicine Name: "+medicineList.get(i).getName()+" Current Quantity: "+
			medicineQuantityList.get(i));
			}
			System.out.println((medicineList.size()+1)+"- GoBack");
			do {
				System.out.print("Enter Here: ");
				choice=sc.nextInt();
				if(choice<1 || choice>(medicineList.size()+1))
				{
					System.out.println("Error, Invalid choice please enter again.");
				}
			}while(choice<1 || choice>(medicineList.size()+1));
			if(choice<(medicineList.size()+1))
			{
				do {
				System.out.print("Enter the quantity to be added: ");
				quantity=sc.nextInt();
				if(quantity<=0)
				{
					System.out.println("Error, Invalid quantity please enter again.");
				}
				}while(quantity<=0);
				System.out.print("The quantity of "+medicineList.get(choice-1).getName()+" is changed from "
						+ medicineQuantityList.get(choice-1)+" to ");
				medicineQuantityList.set(choice-1, (medicineQuantityList.get(choice-1)+quantity));
				System.out.println(medicineQuantityList.get(choice-1));
				StockMedicineWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				
			}
			else
			{
				checkStockMedicine();
			}
			break;
		case 2:
			for(int i=0;i<medicineList.size();i++)
			{
				System.out.println((i+1)+"-"+" Medicine Name: "+medicineList.get(i).getName()+" Current Quantity: "+
			medicineQuantityList.get(i));
			}
			System.out.println((medicineList.size()+1)+"- GoBack");
			do {
				System.out.print("Enter Here: ");
				choice=sc.nextInt();
				if(choice<1 || choice>(medicineList.size()+1))
				{
					System.out.println("Error, Invalid choice please enter again.");
				}
			}while(choice<1 || choice>(medicineList.size()+1));
			if(choice<(medicineList.size()+1))
			{
				do {
				System.out.print("Enter the quantity to be reduced: ");
				quantity=sc.nextInt();
				if(quantity<=0 || quantity>medicineQuantityList.get(choice-1))
				{
					System.out.println("Error, Invalid quantity please enter again.");
				}
				}while(quantity<=0 || quantity>medicineQuantityList.get(choice-1));
				System.out.print("The quantity of "+medicineList.get(choice-1).getName()+" is changed from "
						+ medicineQuantityList.get(choice-1)+" to ");
				medicineQuantityList.set(choice-1, (medicineQuantityList.get(choice-1)-quantity));
				System.out.println(medicineQuantityList.get(choice-1));
				StockMedicineWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				
			}
			else
			{
				checkStockMedicine();
			}
			 break;
		case 3:
			for(int i=0;i<medicineList.size();i++)
			{
				System.out.println((i+1)+"-"+" Medicine Name: "+medicineList.get(i).getName()+" Quantity: "+
						medicineQuantityList.get(i));
			}
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 4:
			mainMenu();
			 break;
		}
	}
	
	public static void checkStockSkin() {
		int quantity;
		System.out.print("1)Add Quantity For a skin care product\n2)Reduce Quantity For a skin care product\n"
				+ "3)Print skin care products Stock\n"
				+ "4)GoBack\n");
		do {
			System.out.print("Enter Here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>4)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>4);
		switch(choice)
		{
		case 1:
			for(int i=0;i<skinProductsList.size();i++)
			{
				System.out.println((i+1)+"-"+" SkinCare Product Name: "+skinProductsList.get(i).getName()+" Current Quantity: "+
			skinQuantityList.get(i));
			}
			System.out.println((skinProductsList.size()+1)+"- GoBack");
			do {
				System.out.print("Enter Here: ");
				choice=sc.nextInt();
				if(choice<1 || choice>(skinProductsList.size()+1))
				{
					System.out.println("Error, Invalid choice please enter again.");
				}
			}while(choice<1 || choice>(skinProductsList.size()+1));
			if(choice<(skinProductsList.size()+1))
			{
				do {
				System.out.print("Enter the quantity to be added: ");
				quantity=sc.nextInt();
				if(quantity<=0)
				{
					System.out.println("Error, Invalid quantity please enter again.");
				}
				}while(quantity<=0);
				System.out.print("The quantity of "+skinProductsList.get(choice-1).getName()+" is changed from "
						+ skinQuantityList.get(choice-1)+" to ");
				skinQuantityList.set(choice-1, (skinQuantityList.get(choice-1)+quantity));
				System.out.println(skinQuantityList.get(choice-1));
				StockSkinWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				
			}
			else
			{
				checkStockMedicine();
			}
			break;
		case 2:
			for(int i=0;i<skinProductsList.size();i++)
			{
				System.out.println((i+1)+"-"+" SkinCare Product Name: "+skinProductsList.get(i).getName()+" Current Quantity: "+
						skinQuantityList.get(i));
			}
			System.out.println((skinProductsList.size()+1)+"- GoBack");
			do {
				System.out.print("Enter Here: ");
				choice=sc.nextInt();
				if(choice<1 || choice>(skinProductsList.size()+1))
				{
					System.out.println("Error, Invalid choice please enter again.");
				}
			}while(choice<1 || choice>(skinProductsList.size()+1));
			if(choice<(skinProductsList.size()+1))
			{
				do {
				System.out.print("Enter the quantity to be reduced: ");
				quantity=sc.nextInt();
				if(quantity<=0 || quantity>skinQuantityList.get(choice-1))
				{
					System.out.println("Error, Invalid quantity please enter again.");
				}
				}while(quantity<=0 || quantity>skinQuantityList.get(choice-1));
				System.out.print("The quantity of "+skinProductsList.get(choice-1).getName()+" is changed from "
						+ skinQuantityList.get(choice-1)+" to ");
				skinQuantityList.set(choice-1, (skinQuantityList.get(choice-1)-quantity));
				System.out.println(skinQuantityList.get(choice-1));
				StockSkinWriter();
				do {
		            System.out.print("\nEnter 1 to go back to main menu:");
		            choice=sc.nextInt();
		            if(choice!=1)
		            {
		                System.out.print("Invalid entry.");
		            }
		            }while(choice!=1);
		            if(choice==1)
		            {
		                mainMenu();
		            }
				
			}
			else
			{
				checkStockSkin();
			}
			 break;
		case 3:
			for(int i=0;i<skinProductsList.size();i++)
			{
				System.out.println((i+1)+"-"+" SkinCare Product Name: "+skinProductsList.get(i).getName()+" Quantity: "+
						skinQuantityList.get(i));
			}
			do {
	            System.out.print("\nEnter 1 to go back to main menu:");
	            choice=sc.nextInt();
	            if(choice!=1)
	            {
	                System.out.print("Invalid entry.");
	            }
	            }while(choice!=1);
	            if(choice==1)
	            {
	                mainMenu();
	            }
			break;
		case 4:
			mainMenu();
			 break;
		}
	}
	/////////////////////////////////
	public static void aboutProducts()
	{
		
		System.out.print("1)Add Product\n"
				+ "2)Remove Product\n"
				+ "3)Manage Product\n"
				+ "4)Display Product\n"
				+ "5)Search For Product\n"
				+ "6)GoBack\n");
		do {
			System.out.print("Enter Here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>6)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>6);
		switch(choice)
		{
		case 1:
			addProduct();
			break;
		case 2:
			removeProduct();
			break;
		case 3:
			manageProduct();
			break;
		case 4:
			displayProduct();
			break;
		case 5:
			searchProduct();
			break;
		case 6:
			mainMenu();
			break;
		}
	}
	///////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////
	public static void aboutPharmacy()
	{
		String pharmacyName="K&A PHARMACY";
		String address="BEIRUT";
		Date dateOfOpening=new Date(14,12,2022);
		ArrayList<String> owners=new ArrayList<String>();
		ArrayList<String> phoneNumbers=new ArrayList<String>();
		owners.add("Kassem Chamseddine");
		owners.add("Amine Ezzeddine");
		phoneNumbers.add("03543016");
		phoneNumbers.add("81099146");

		Pharmacy p=new Pharmacy(pharmacyName,dateOfOpening,owners,phoneNumbers,address);
		System.out.println(p.getPharmacyInfo(pharmaList,cashList,skinList,medicineList,skinProductsList));
		System.out.print("\n\n");
		System.out.print("1)GoBack To MainMenu\n2)Exit\n");
		do {
			System.out.print("Enter here: ");
			choice=sc.nextInt();
			if(choice<1 || choice>2)
			{
				System.out.println("Error, Invalid choice please enter again.");
			}
		}while(choice<1 || choice>2);
		switch(choice)
		{
		case 1:
			mainMenu();
			break;
		case 2:
			System.out.println("Exiting Program...");
			break;
		}
		
	}

	
		
		
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void main(String args[]) throws IOException
	{
		
		design();
		try {
			BufferedReader reader =new BufferedReader(new FileReader("\\C:\\Users\\96135\\Desktop\\Emp.txt\\"));
			String line=reader.readLine();
			Date dob,doh;
			char gender;
			while(line !=null)
			{
				String[] splits = line.split(",");
				gender=splits[2].charAt(0);
				String[] dobSplits = splits[3].split("/");
				dob=new Date(Integer.parseInt(dobSplits[0]),Integer.parseInt(dobSplits[1]),Integer.parseInt(dobSplits[2])); 
				String[] dohSplits = splits[4].split("/");
				doh=new Date(Integer.parseInt(dohSplits[0]),Integer.parseInt(dohSplits[1]),Integer.parseInt(dohSplits[2]));  
				
				emp=new Employee(splits[0],splits[1],gender,dob,doh,splits[5],splits[6],Double.parseDouble(splits[7])
						,splits[8],Integer.parseInt(splits[9]));
				
				if(splits[5].equalsIgnoreCase("pharma"))
				{
					pharmaList.add(emp);
				}
				else if(splits[5].equalsIgnoreCase("skin care specialist"))
				{
					skinList.add(emp);
				}
				else if(splits[5].equalsIgnoreCase("cashier"))
				{
					cashList.add(emp);
				}
				
				
				// read next line
				line = reader.readLine();
			}
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			BufferedReader reader =new BufferedReader(new FileReader("\\C:\\Users\\96135\\Desktop\\Med.txt\\"));
			String line=reader.readLine();
			Date produceDate,expireDate;
			char gender;
			boolean requirePrescription=false;
			while(line != null)
			{
				String[] splits = line.split(",");
				String[] produceSplits = splits[1].split("/");
				produceDate=new Date(Integer.parseInt(produceSplits[0]),Integer.parseInt(produceSplits[1])); 
				String[] expireSplits = splits[2].split("/");
				expireDate=new Date(Integer.parseInt(expireSplits[0]),Integer.parseInt(expireSplits[1]));  
				if(splits[6].equalsIgnoreCase("yes"))
				{
					requirePrescription=true;
				}
				else if(splits[6].equalsIgnoreCase("no"))
				{
					requirePrescription=false;
				}
				med=new Medicine(splits[0],produceDate,expireDate,splits[3],Double.parseDouble(splits[4]),
						Double.parseDouble(splits[5]),requirePrescription,splits[7]);
				medicineList.add(med);
				
				// read next line
				line = reader.readLine();
			}
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			BufferedReader reader =new BufferedReader(new FileReader("\\C:\\Users\\96135\\Desktop\\SkinProduct.txt\\"));
			String line=reader.readLine();
			Date produceDate,expireDate;
			char gender;
			boolean naturalOrChemical=false;;
			while(line !=null)
			{
				String[] splits = line.split(",");
				String[] produceSplits = splits[1].split("/");
				produceDate=new Date(Integer.parseInt(produceSplits[0]),Integer.parseInt(produceSplits[1])); 
				String[] expireSplits = splits[2].split("/");
				expireDate=new Date(Integer.parseInt(expireSplits[0]),Integer.parseInt(expireSplits[1]));  
				if(splits[6].equalsIgnoreCase("natural"))
				{
					naturalOrChemical=true;
				}
				else if(splits[6].equalsIgnoreCase("chemical"))
				{
					naturalOrChemical=false;
				}
				skinProduct=new SkinCareProducts(splits[0],produceDate,expireDate,splits[3],Double.parseDouble(splits[4]),
						Double.parseDouble(splits[5]),naturalOrChemical,splits[7]);
				skinProductsList.add(skinProduct);
				
				// read next line
				line = reader.readLine();
			}
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			BufferedReader reader=new BufferedReader(new FileReader("\\C:\\Users\\96135\\Desktop\\MedicineStock.txt\\"));
			String line = reader.readLine();
			while(line!=null)
			{
				String[] splits = line.split(",");
				if(Integer.parseInt(splits[1])>0)
				{
					medicineInStock.add(splits[0]);
				}
				else
				{
					medicineOutStock.add(splits[0]);
				}
				medicineQuantityList.add(Integer.parseInt(splits[1]));
				line = reader.readLine();
				
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			BufferedReader reader=new BufferedReader(new FileReader("\\C:\\Users\\96135\\Desktop\\SkinStock.txt\\"));
			String line = reader.readLine();
			while(line!=null)
			{
				String[] splits = line.split(",");
				if(Integer.parseInt(splits[1])>0)
				{
					skinInStock.add(splits[0]);
				}
				else
				{
					skinOutStock.add(splits[0]);
				}
				skinQuantityList.add(Integer.parseInt(splits[1]));
				line = reader.readLine();
				
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		mainMenu();
	}
}
