package progFinalProject;

import java.util.*;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime; 
public class Client {

		private ArrayList<String> medicinePurchased=new ArrayList<>();
	    private ArrayList<Integer> medicineQty=new ArrayList<>();
	    private ArrayList<String> skinPurchased=new ArrayList<>();
	    private ArrayList<Integer> skinQty=new ArrayList<>();
	    private Date dateOfPurchase;
	    
		public Client() {
			
		}

		public Client(ArrayList<String> medicinePurchased, ArrayList<String> skinPurchased, ArrayList<Integer> medicineQty,
				ArrayList<Integer> skinQty,Date dateOfPurchase) {
			
			this.medicinePurchased = medicinePurchased;
			this.skinPurchased = skinPurchased;
			this.medicineQty = medicineQty;
			this.skinQty = skinQty;
			this.dateOfPurchase = dateOfPurchase;
		}

		public ArrayList<String> getMedicinePurchased() {
			return medicinePurchased;
		}

		public void setMedicinePurchased(ArrayList<String> medicinePurchased) {
			this.medicinePurchased = medicinePurchased;
		}

		public ArrayList<String> getSkinPurchased() {
			return skinPurchased;
		}

		public void setSkinPurchased(ArrayList<String> skinPurchased) {
			this.skinPurchased = skinPurchased;
		}

		public String getDateOfPurchase() {
			return dateOfPurchase.printEmpDate();
		}

		public void setDateOfPurchase(Date dateOfPurchase) {
			this.dateOfPurchase = dateOfPurchase;
		}
		
		
		
		public ArrayList<Integer> getMedicineQty() {
			return medicineQty;
		}

		public void setMedicineQty(ArrayList<Integer> medicineQty) {
			this.medicineQty = medicineQty;
		}

		public ArrayList<Integer> getSkinQty() {
			return skinQty;
		}

		public void setSkinQty(ArrayList<Integer> skinQty) {
			this.skinQty = skinQty;
		}
		public String printMedicinePurchased()
		{
			String result="";
			for(int i=0;i<medicinePurchased.size();i++)
			{
				if(i == medicinePurchased.size() - 1)
				{
					result+= medicinePurchased.get(i);
				}
				else
				{
					result+= medicinePurchased.get(i)+",";
				}
			}
			return result;
		}
		public String printMedicineQuantity()
		{
			String result="";
			for(int i=0;i<medicineQty.size();i++)
			{
				if(i == medicineQty.size() - 1)
				{
					result+= medicineQty.get(i);
				}
				else
				{
					result+= medicineQty.get(i)+",";
				}
			}
			return result;
		}
		public String printSkinPurchased()
		{
			String result="";
			for(int i=0;i<skinPurchased.size();i++)
			{
				if(i == skinPurchased.size() - 1)
				{
					result+= skinPurchased.get(i);
				}
				else
				{
					result+= skinPurchased.get(i)+",";
				}
			}
			return result;
		}
		public String printSkinQuantity()
		{
			String result="";
			for(int i=0;i<skinQty.size();i++)
			{
				if(i == skinQty.size() - 1)
				{
					result+= skinQty.get(i);
				}
				else
				{
					result+= skinQty.get(i)+",";
				}
			}
			return result;
		}
		public void buyMedicine(ArrayList<Medicine> medicineList,ArrayList<Integer> quantityList,int index, 
				int quantity,ArrayList<String> medicinePurchased,ArrayList<Integer> medicineQty)
	    {            
						medicinePurchased.add(medicineList.get(index-1).getName());
	                    medicineQty.add(quantity);
	                    quantityList.set(index-1, quantityList.get(index-1)-quantity);
	                    this.medicineQty=medicineQty;
	                    this.medicinePurchased=medicinePurchased;
	    }
		public void buySkin(ArrayList<SkinCareProducts> skinList,ArrayList<Integer> quantityList,int index, 
				int quantity,ArrayList<String> skinPurchased,ArrayList<Integer> skinQty)
	    {            
			skinPurchased.add(skinList.get(index-1).getName());
            skinQty.add(quantity);
            quantityList.set(index-1, quantityList.get(index-1)-quantity);
            this.skinQty=skinQty;
            this.skinPurchased=skinPurchased;
	    }
		
//	    public void returnMedicine(ArrayList<Medicine> medicineList,ArrayList<Integer> quantityList,int quantity, String medicineName)
//	    {
//	        for(int i=0;i<medicineList.size();i++)
//	        {
//	            if(medicineList.get(i).getName().equalsIgnoreCase(medicineName))
//	            {
//	            	 
//	            	quantityList.set(i, quantityList.get(i) + quantity);
//	            }
//	        }
//	        for (int i = 0; i < medicinePurchased.size(); i++) {
//	        	if(medicinePurchased.get(i).equalsIgnoreCase(medicineName)) {
//	                if(medicineQty.get(i).equals(quantity)){
//	                    medicineQty.remove(i);
//	                    medicinePurchased.remove(i);
//	                }
//	                else {
//	                    medicineQty.set(i, medicineQty.get(i)-quantity);
//	                }
//			}
//	            	
//	            	}
//	                    System.out.println(quantity+" medicine(s) of name "+medicineName+" were returned.");
//	            }
//	        
	    
	    
//	    public void returnSkin(ArrayList<SkinCareProducts> skinList,ArrayList<Integer> quantityList,int quantity, String skinName)
//	    {
//	    	 for(int i=0;i<skinList.size();i++)
//	         {
//	             if(skinList.get(i).getName().equalsIgnoreCase(skinName))
//	             {
//	             	 
//	             	quantityList.set(i, quantityList.get(i) + quantity);
//	             }
//	         }
//	         for (int i = 0; i < medicinePurchased.size(); i++) {
//	        	 
//	         	if(medicinePurchased.get(i).equalsIgnoreCase(skinName)) {
//	                 if(skinQty.get(i).equals(quantity)){
//	                     skinQty.remove(i);
//	                     skinPurchased.remove(i);
//	                 }
//	                 else {
//	                     skinQty.set(i, skinQty.get(i)-quantity);
//	                 }
//	 		}
//	             	
//	             	}
//	                     System.out.println(quantity+" Skin care product(s) of name "+skinName+" were returned.");
//	             }
//	    
		 
//	    public double calcAmountSales(ArrayList<Medicine> medicineList, ArrayList<SkinCareProducts> skinList) {
//	    	double amount = 0;
//	    	for(int i=0;i<medicinePurchased.size();i++)
//	    	{
//	    		
//	    	}
//	    	for(int i =0; i < medicineList.size(); i++) {
//	    		for(int j=0;j<medicinePurchased.size();i++)
//	    		{
//	    			if(medicineList.get(i).getName().equalsIgnoreCase(medicinePurchased.get(j))) {
//		    			amount += medicineList.get(i).getPrice() * medicineQty.get(j);
//	    		}
//	  
//	    	}
//	    }
//	    	for(int i =0; i < skinList.size(); i++) {
//	    		for(int j=0;j<skinPurchased.size();i++)
//	    		{
//	    			if(medicineList.get(i).getName().equalsIgnoreCase(skinPurchased.get(j))) {
//		    			amount += medicineList.get(i).getPrice() * skinQty.get(j);
//	    		}
//	    	}
//	    }
//	    	return amount;
//	    	
//	    }
	    
//	    public double calcAmountProfits(ArrayList<Medicine> medicineList, ArrayList<SkinCareProducts> skinList) {
//	    	double amountProfit = 0;
//	    	for (int i = 0; i < medicineList.size(); i++) {
//	    		for(int j=0;j<medicinePurchased.size();i++)
//	    		{
//	    			if(medicineList.get(i).getName().equalsIgnoreCase(medicinePurchased.get(j))) {
//		    			amountProfit += medicineList.get(i).getPrice() * medicineQty.get(j) - medicineList.get(i).getWholeSalePrice() * medicineQty.get(j);
//		    		}
//	    		}
//			}
//	    	for(int i =0; i < skinList.size(); i++) {
//	    		for(int j=0;j<medicinePurchased.size();i++)
//	    		{
//	    			if(skinList.get(i).getName().equalsIgnoreCase(medicinePurchased.get(j))) {
//		    			amountProfit += (skinList.get(i).getPrice() * skinQty.get(j)) - (skinList.get(i).getWholeSalePrice()* skinQty.get(j));
//		    		}
//	    		}
//	    }
//		return amountProfit;
//	    }
//	    
	    	public String toString()
	        {
	            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");  
	            LocalDateTime now = LocalDateTime.now();
	            return "••••••K&A PHARMACY••••••\nReciept\t\t\t"+this.dateOfPurchase+" "+dtf.format(now)
	            +"\n------------------------------------\n";
	            
	        }
	    	
	    
	}


