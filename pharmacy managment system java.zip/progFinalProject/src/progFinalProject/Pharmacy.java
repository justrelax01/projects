package progFinalProject;
import java.util.ArrayList;
public class Pharmacy {
	private String name;
	private Date dateOfOpening=new Date();
	private ArrayList<String> owners=new ArrayList<String>();
	private ArrayList<String> phoneNumbers=new ArrayList<String>();
	private String address;
	private Employee employee = new Employee();
	private Medicine medicines = new Medicine();
	private SkinCareProducts products = new SkinCareProducts();
	private Client clients;
	
	public Pharmacy()
	{
		
	}
	public Pharmacy(String name, Date dateOfOpening, ArrayList<String> owners, ArrayList<String> phoneNumbers,
			String address) {
		this.name = name;
		this.dateOfOpening = dateOfOpening;
		this.owners = owners;
		this.phoneNumbers = phoneNumbers;
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateOfOpening() {
		return dateOfOpening;
	}
	public void setDateOfOpening(Date dateOfOpening) {
		this.dateOfOpening = dateOfOpening;
	}
	public ArrayList<String> getOwners() {
		return owners;
	}
	public void setOwners(ArrayList<String> owners) {
		this.owners = owners;
	}
	public ArrayList<String> getPhoneNumbers() {
		return phoneNumbers;
	}
	public void setPhoneNumbers(ArrayList<String> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Medicine getMedicines() {
		return medicines;
	}
	public void setMedicines(Medicine medicines) {
		this.medicines = medicines;
	}
	public SkinCareProducts getProducts() {
		return products;
	}
	public void setProducts(SkinCareProducts products) {
		this.products = products;
	}
	public String getPharmacyInfo(ArrayList<Employee> pharmaList,ArrayList<Employee> cashList,ArrayList<Employee> skinList
			,ArrayList<Medicine> medicineList,ArrayList<SkinCareProducts> skinProductsList)
	{
		String result;
		result="Pharmacy Name: "+this.name+"\nOwners:\n";
		for(int i=0;i<owners.size();i++)
		{
			result+=owners.get(i) + "\n";
		}
		result+="Phone Numbers:\n";
		for(int i=0;i<phoneNumbers.size();i++)
		{
			result+=phoneNumbers.get(i)+ "\n";
		}
		result+="Address: "+this.address+"\nDate Of Opening: "+this.dateOfOpening.printEmpDate()+"\nOpening Time: 8am-10pm\n"+""
				+ "*****Pharmas*****\n";
		for(int i=0;i<pharmaList.size();i++)
		{
			result+=pharmaList.get(i);
		}
		result+="*****Cashiers*****\n";
		for(int i=0;i<cashList.size();i++)
		{
			result+=cashList.get(i);
		}
		result+="*****SkinCare Specialists*****\n";
		for(int i=0;i<skinList.size();i++)
		{
			result+=skinList.get(i);
		}
		result+="*****Medicines*****\n";
		for(int i=0;i<medicineList.size();i++)
		{
			result+=medicineList.get(i);
		}
		result+="\n*****SkinCare Products*****\n";
		for(int i=0;i<skinProductsList.size();i++)
		{
			result+=skinProductsList.get(i);
		}
		return result;
		
		
	}
	
	
}
