package progFinalProject;

import java.util.ArrayList;

public class SkinStock extends SkinCareProducts{
	private int quantity;
	
	public SkinStock()
	{
		super();
	}
	public SkinStock(String skinCareName,int quantity)
	{
		super(skinCareName);
		if(quantity>=0)
		{
			this.quantity=quantity;
		}
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		if(quantity>=0)
		{
			this.quantity=quantity;
		}
		else
		{
			System.out.println("Error, Invalid quantity.");
		}
	}

	public void addQuantity(ArrayList<SkinCareProducts> skinList,ArrayList<Integer> quantityList,int index,int quantity)
	{
		quantityList.set(index-1,quantityList.get(index-1)+quantity);
	}
	public void reduceQuantity(ArrayList<SkinCareProducts> skinList,ArrayList<Integer> quantityList,int index,int quantity)
	{
		if(quantityList.get(index-1)>=quantity)
		{
			quantityList.set(index,quantityList.get(index-1)-quantity);
			this.quantity=quantityList.get(index-1);
		}
		else
		{
			System.out.println("The quantity entered is greater than the stored quantity!");
		}
	}
	public void outStock(ArrayList<SkinCareProducts> skinList,ArrayList<Integer> quantityList,
			ArrayList<String> outStock)
	{
		for(int i=0;i<quantityList.size();i++)
		{
			if(quantityList.get(i)==0)
			{
				outStock.add(skinList.get(i).getName());
			}
		}
	}
	public void inStock(ArrayList<SkinCareProducts> skinList,ArrayList<Integer> quantityList,
			ArrayList<String> inStock)
	{
		for(int i=0;i<quantityList.size();i++)
		{
			if(quantityList.get(i)>0)
			{
				inStock.add(skinList.get(i).getName());
			}
		}
	}
	public void printOutStock(ArrayList<String> outStock)
	{
		System.out.println("Total Skin care products out of stock: "+outStock.size());
		for(int i=0;i<outStock.size();i++)
		{
			System.out.println((i+1)+"-"+outStock.get(i));
		}
	}
	public void printInStock(ArrayList<String> inStock,ArrayList<Integer> quantityList)
	{
		System.out.println("Total Skin care products in stock: "+inStock.size());
		for(int i=0;i<quantityList.size();i++)
		{
			if(quantityList.get(i)!=0)
			{
				System.out.println((i+1)+"-"+inStock.get(i)+": "+quantityList.get(i));
			}
		}
	}
	public String toString()
	{
		return "SkinCare Product's Name: "+super.getName()+" Quantity: "+this.quantity+"\n";
	}

}
