package progFinalProject;

import java.util.ArrayList;

public class Products {
	private String name;
	private Date produceDate,expireDate;
//	private Agent agent;
	private String ingredients;
	private double price;
	private double wholeSalePrice;
	
	public Products()
	{
		
	}
	public Products(String name)
	{
		this.name=name;
	}
	public Products(String name,Date produceDate,Date expireDate,String ingredients,double price,
			double wholeSalePrice)
	{
		this.name=name;
		this.produceDate=produceDate;
		this.expireDate=expireDate;
//		this.agent=agent;
		this.ingredients=ingredients;
		if(price>0)
		{
			this.price=price;
		}
		else {
			this.price=0;
		}
		if(wholeSalePrice>0)
		{
			this.wholeSalePrice=wholeSalePrice;
		}
		else {
			this.wholeSalePrice=0;
		}
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProduceDate() {
		return produceDate.printMedDate();
	}
	public void setProduceDate(Date produceDate) {
		this.produceDate = produceDate;
	}
	public String getExpireDate() {
		return expireDate.printMedDate();
	}
	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}
//	public Agent getAgent() {
//		return agent;
//	}
//	public void setAgent(Agent agent) {
//		this.agent = agent;
//	}
	public String getIngredients() {
		return ingredients;
	}
	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		if(price>0)
		{
			this.price=price;
		}
		else {
			System.out.println("Error, Invalid price!");;
		}
	}
	public double getWholeSalePrice() {
		return wholeSalePrice;
	}
	public void setWholeSalePrice(double wholeSalePrice) {
		if(wholeSalePrice>0)
		{
			this.wholeSalePrice=wholeSalePrice;
		}
		else {
			System.out.println("Error, Invalid whole sale price!");
		}
	}
	
	public String toString()
	{
		return "Name: "+this.name+"\nPrice: "+this.price+" $ "+"\nProduce Date: "+this.produceDate.printMedDate()+
				"\nExpiry Date: "+this.expireDate.printMedDate()
				+"\nIngredients: "+this.ingredients;
	}
	
	
	

}
