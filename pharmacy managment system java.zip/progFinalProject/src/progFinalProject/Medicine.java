package progFinalProject;
import java.util.*;
public class Medicine extends Products{
	private boolean requirePrescription;
	private String type;
	//private ArrayList<String> sideEffects=new ArrayList<String>();
	
	public Medicine()
	{
		super();
	}

	public Medicine(String medicineName)
	{
		super(medicineName);
	}
	public Medicine(String medicineName, Date produceDate, Date expireDate,
			String ingredients, double price,double wholeSalePrice,boolean requirePrescription,String type) {
		super(medicineName,produceDate,expireDate,ingredients,price,wholeSalePrice);
		
		if(requirePrescription==true || requirePrescription==false)
		{
			this.requirePrescription=requirePrescription;
		}
		
		else
		{
			this.requirePrescription=false;
		}
		
		if(type.equalsIgnoreCase("Liquid") || type.equalsIgnoreCase("Tablets") ||
                type.equalsIgnoreCase("Capsules") || type.equalsIgnoreCase("Injections") || type.equalsIgnoreCase("Inhalers")
                 || type.equalsIgnoreCase("Implants") || type.equalsIgnoreCase("Drops")) {
            this.type = type;
        }
		//this.sideEffects=sideEffects;
	}

	public boolean isRequirePrescription() {
		return requirePrescription;
	}
	public String requirePrescription() {
		String a;
		if(this.requirePrescription==true)
		{
			a="Yes";
		}
		else
		{
			a="No";
		}
		return a;
	}

	public void setRequirePrescription(boolean requirePrescription) {
		if(requirePrescription==true || requirePrescription==false)
		{
			this.requirePrescription=requirePrescription;
		}
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		if(type.equalsIgnoreCase("Liquid") || type.equalsIgnoreCase("Tablets") ||
                type.equalsIgnoreCase("Capsules") || type.equalsIgnoreCase("Injections") || type.equalsIgnoreCase("Inhalers")
                 || type.equalsIgnoreCase("Implants") || type.equalsIgnoreCase("Drops")) {
            this.type = type;
        }
		else
		{
			System.out.println("This type is not found, please enter a valid type.");
		}
	}
	
//	public ArrayList<String> getSideEffects() {
//		return sideEffects;
//	}
//
//	public void setSideEffects(ArrayList<String> sideEffects) {
//		this.sideEffects = sideEffects;
//	}
	public void addMedicine(ArrayList<Medicine> medicineList,Medicine m)
	{
		medicineList.add(m);
	}
	public void removeMedicine(ArrayList<Medicine>  medicineList,int index)
	{
		medicineList.remove(index-1);
	}
	public void printMedicines(ArrayList<Medicine> medicineList)
	{
		System.out.println("***The available medicines***");
		for(int i=0;i<medicineList.size();i++)
		{
			System.out.println("Medicine "+(i+1)+" :\n"+medicineList.get(i));
		}
	}
	public void searchForMedicine(ArrayList<Medicine> medicineList,String name)
	{
		boolean found=true;
		Medicine info=null;
		for(int i=0;i<medicineList.size();i++)
		{
			if(medicineList.get(i).getName().equalsIgnoreCase(name))
			{
				System.out.println("The medicine of name "+name+" is found with the following info:\n"+medicineList.get(i));
			}
			else
			{
				found=false;
			}
		}
		if(!found)
		{
			System.out.println("The medicine of name "+name+" is not found.");
		}
		
	}
	public void printMedWithPresc(ArrayList<Medicine> medicineList)
	{
		System.out.println("Medicines that require prescription:");
		for(int i=0;i<medicineList.size();i++)
		{
			if(medicineList.get(i).isRequirePrescription())
			{
				System.out.println((i+1)+")"+medicineList.get(i).getName());
			}
		}
	}
	public void printMedWithoutPresc(ArrayList<Medicine> medicineList)
	{
		System.out.println("Medicines that do not require prescription:");
		for(int i=0;i<medicineList.size();i++)
		{
			if(medicineList.get(i).isRequirePrescription()==false)
			{
				System.out.println((i+1)+")"+medicineList.get(i).getName());
			}
		}
	}
//	public void printsideEffectsForFile(ArrayList<Medicine> medicineList)
//	{
//		for(int i=0;i<medicineList.size();i++)
//		{
//			System.out.print(medicineList.get(i).get);
//		}
//	}
//	public void printSideEffects(ArrayList<Medicine> medicineList,String name)
//	{
//		System.out.println("The side effects of "+name+" are: ");
//		for(int i=0;i<medicineList.size();i++)
//		{
//			if(medicineList.get(i).getName().equalsIgnoreCase(name))
//			{
//				for(int j=0;j<sideEffects.size();j++)
//				{
//					System.out.println(sideEffects.get(j));
//				}
//			}
//		}
//	}
	
	public void printSpecifictype(ArrayList<Medicine> medicineList,String type)
	{
		System.out.println("Medicines having type "+type+" are: ");
		for(int i=0;i<medicineList.size();i++)
		{
			if(medicineList.get(i).getType().equalsIgnoreCase(type))
			{
				System.out.println((i+1)+")"+medicineList.get(i).getName());
			}
		}
	}
	public void printAllTypes(ArrayList<Medicine> medicineList)
	{
		int liquid=0,tablets=0,capsules=0,injections=0,inhalers=0,implants=0,drops=0;
		System.out.println("Liquid\t\tTablets\t\tCapsules\t\tInjections\t\tInhalers\t\tImplants\t\tDrops");
		for(int i=0;i<medicineList.size();i++)
		{
			if(medicineList.get(i).getType().equalsIgnoreCase("Liquid"))
			{
				System.out.println((liquid+1)+")"+medicineList.get(i).getName());
				liquid++;
			}
			else if(medicineList.get(i).getType().equalsIgnoreCase("Tablets"))
			{
				System.out.println("\t\t"+(tablets+1)+")"+medicineList.get(i).getName());
				tablets++;
			}
			else if(medicineList.get(i).getType().equalsIgnoreCase("Capsules"))
			{
				System.out.println("\t\t\t\t"+(capsules+1)+")"+medicineList.get(i).getName());
				capsules++;
			}
			else if(medicineList.get(i).getType().equalsIgnoreCase("Injections"))
			{
				System.out.println("\t\t\t\t\t\t"+(injections+1)+")"+medicineList.get(i).getName());
				injections++;
			}
			else if(medicineList.get(i).getType().equalsIgnoreCase("Inhalers"))
			{
				System.out.println("\t\t\t\t\t\t\t\t"+(inhalers+1)+")"+medicineList.get(i).getName());
				inhalers++;
			}
			else if(medicineList.get(i).getType().equalsIgnoreCase("Implants"))
			{
				System.out.println("\t\t\t\t\t\t\t\t\t\t"+(implants+1)+")"+medicineList.get(i).getName());
				implants++;
			}
			else if(medicineList.get(i).getType().equalsIgnoreCase("Drops"))
			{
				System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t"+(drops+1)+")"+medicineList.get(i).getName());
				drops++;
			}
		}
	}
	
	public String toString()
	{
		String result= "Medicine Info:\n"+super.toString()+"\nType: "+this.type+"\nRequires Presciption: "+
						requirePrescription();
//		for(int i=0;i<sideEffects.size();i++)
//		{
//			result+=(i+1)+"-"+sideEffects.get(i)+"\n";
//		}
		return result;
	}
	
	
	
	

}
