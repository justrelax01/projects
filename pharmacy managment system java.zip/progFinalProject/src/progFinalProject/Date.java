package progFinalProject;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;

public class Date {
	private int day;
	private int month;
	private int year;
	
	public Date()
	{
		
	}
	public Date(int month,int year)
	{
		if(month>=1 && month<=12)
		{
			this.month=month;
		}
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
        LocalDateTime now = LocalDateTime.now();
        
        if(year>=2000 && year<=Integer.parseInt(dtf.format(now))+15 )
        {
        	this.year=year;
        }
	}
	public Date(int day,int month,int year)
	{
		if(month>=1 && month<=12)
		{
			this.month=month;
		}
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
        LocalDateTime now = LocalDateTime.now();
        
        
        if(year>=1950 && year<=Integer.parseInt(dtf.format(now)) )
        {
        	this.year=year;
        }
        
        switch(month)
        {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
        	if(day>=1 && day<=31)
        		this.day=day;
        	break;
        case 4:
        case 6:
        case 9:
        case 11:
        	if(day>=1 && day<=30)
        		this.day=day;
        	break;
        case 2:
        	if((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0))
        	{
        		if(day>=1 && day<=29)
        		{
        			this.day=day;
        		}
        	}
        	else
        	{
        		if(day>=1 && day<=28)
        		{
        			this.day=day;
        		}
        	}
        	break;
        }
		
	}
	
	
	
	public int getDay() {
		return day;
	}



	public void setDay(int day) {
		switch(this.month)
        {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
        	if(day>=1 && day<=31)
        		this.day=day;
        	else
        	{
        		System.out.println("Error, Invalid day!Please re-enter a value between 1 and 31.");
        	}
        	break;
        case 4:
        case 6:
        case 9:
        case 11:
        	if(day>=1 && day<=30)
        		this.day=day;
        	else
        	{
        		System.out.println("Error, Invalid day!Please re-enter a value between 1 and 30.");
        	}
        	break;
        case 2:
        	if((this.year % 4 == 0) && (this.year % 100 != 0) || (this.year % 400 == 0))
        	{
        		if(day>=1 && day<=29)
        		{
        			this.day=day;
        		}
        		else
        		{
        			System.out.println("Error, Invalid day!Please re-enter a value between 1 and 29.");
        		}
        	}
        	else
        	{
        		if(day>=1 && day<=28)
        		{
        			this.day=day;
        		}
        		else
        		{
        			System.out.println("Error, Invalid day!Please re-enter a value between 1 and 28.");
        		}
        	}
        	break;
        }
	}



	public int getMonth() {
		return month;
	}



	public void setMonth(int month) {
		if(month>=1 && month<=12)
		{
			this.month=month;
		}
		else
		{
			System.out.println("Error, Invalid month please re-enter a value between 1 and 12.");;
		}
	}



	public int getYear() {
		return year;
	}



	public void setYear(int year) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");  
        LocalDateTime now = LocalDateTime.now();
        
        
        if(year>=1950 && year<=Integer.parseInt(dtf.format(now))+15 )
        {
        	this.year=year;
        }
        else
        {
        	System.out.println("Error, Invalid year!Please re-enter a valid value.");
        }
	}



	public String printEmpDate()
	{
		return day+"/"+month+"/"+year;
	}
	public String printMedDate()
	{
		return month+"/"+year;
	}
	

}
