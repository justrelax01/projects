package progFinalProject;
import java.util.*;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;
public class Employee {
	private String firstname,lastname,degree,position,id,job;
	private char gender;
	private Date dob,doh;
	private static int idNum=1000;
	private double salary;
	private int yearsOfExp;
	private int tempIdNum;
	
	public Employee()
	{
		
	}
	public Employee(String firstname,String lastname,char gender,Date dob,Date doh,String job,
			String position,double salary,String degree,int yearsOfExp)
	{
		this.firstname=firstname;
		this.lastname=lastname;
		this.dob=dob;
		this.doh=doh;
		if(!(gender=='m' || gender=='M' || gender=='f' || gender=='F'))
		{
			this.gender='M';
		}
		else
		{
			this.gender=gender;
		}
		if(salary<0)
			this.salary=0;
		else
			this.salary=salary;
		if(job.equalsIgnoreCase("pharma"))
		{
			this.job=job.toLowerCase();
		}
		else if(job.equalsIgnoreCase("cashier"))
		{
			this.job=job.toLowerCase();
		}
		else if(job.equalsIgnoreCase("skin care specialist"))
		{
			this.job=job.toLowerCase();
		}
		String finalId;
		finalId=this.firstname.substring(0,2).toUpperCase()+"-"+this.lastname.substring(0,2).toLowerCase()+idNum;
		if(job.equalsIgnoreCase("pharma"))
		{
			finalId="PHARMA-"+finalId;
		}
		else if(job.equalsIgnoreCase("cashier"))
		{
			finalId="CASH-"+finalId;
		}
		else
		{
			finalId="SKIN-"+finalId;
		}
		this.id=finalId;
		this.tempIdNum=idNum;
		idNum++;
		if(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
				|| degree.equalsIgnoreCase("professor"))
		{
			this.degree=degree;
		}
		else
		{
			this.degree="Bachelor";
		}
		if(yearsOfExp>=0)
		{
			this.yearsOfExp=yearsOfExp;
		}
		if(position.equalsIgnoreCase("Regular") || position.equalsIgnoreCase("Manager"))
		{
			this.position=position;
		}
		else
		{
			this.position="Regular";
		}
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		String finalId;
		finalId=this.firstname.substring(0,2).toUpperCase()+"-"+this.lastname.substring(0,2).toLowerCase()+idNum;
		if(job.equalsIgnoreCase("pharma"))
		{
			finalId="PHARMA-"+finalId;
		}
		else if(job.equalsIgnoreCase("cashier"))
		{
			finalId="CASH-"+finalId;
		}
		else
		{
			finalId="SKIN-"+finalId;
		}
		this.tempIdNum=idNum;
		idNum++;
		id=finalId;
		this.id=id;
	}
	
	public void repairIdFirstName(String firstName,int id)
	{
		String finalId;
		finalId=firstName.substring(0,2).toUpperCase()+"-"+this.lastname.substring(0,2).toLowerCase()+id;
		if(job.equalsIgnoreCase("pharma"))
		{
			finalId="PHARMA-"+finalId;
		}
		else if(job.equalsIgnoreCase("cashier"))
		{
			finalId="CASH-"+finalId;
		}
		else
		{
			finalId="SKIN-"+finalId;
		}
		this.id=finalId;
	}
	public void repairIdLastName(String lastName,int id)
	{
		String finalId;
		finalId=this.firstname.substring(0,2).toUpperCase()+"-"+lastName.substring(0,2).toLowerCase()+id;
		if(job.equalsIgnoreCase("pharma"))
		{
			finalId="PHARMA-"+finalId;
		}
		else if(job.equalsIgnoreCase("cashier"))
		{
			finalId="CASH-"+finalId;
		}
		else
		{
			finalId="SKIN-"+finalId;
		}
		this.id=finalId;
	}

	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		if(gender=='m' || gender=='M' || gender=='f' || gender=='F')
		{
			this.gender=gender;
		}
		else
		{
			this.gender='M';
		}
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDob() {
		return dob.printEmpDate();
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getDoh() {
		return doh.printEmpDate();
	}
	public void setDoh(Date doh) {
		this.doh = doh;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		if(salary<0)
			System.out.println("Error, Invalid salary!");
		else
			this.salary=salary;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		if(degree.equalsIgnoreCase("Master") || degree.equalsIgnoreCase("phd") || degree.equalsIgnoreCase("bachelor")
				|| degree.equalsIgnoreCase("professor"))
		{
			this.degree=degree;
		}
		else
		{
			System.out.println("Error, Invalid Degree!");
		}
	}
	public int getYearsOfExp() {
		return yearsOfExp;
	}
	public void setYearsOfExp(int yearsOfExp) {
		if(yearsOfExp>=0)
		{
			this.yearsOfExp=yearsOfExp;
		}
		else
		{
			System.out.println("Error, Invalid year(s) of experience.");
		}
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		if(position.equalsIgnoreCase("manager") || position.equalsIgnoreCase("employee"))
		{
			this.position=position;
		}
		else
		{
			System.out.println("Error, Invalid position!");
		}
	}
	
	public static int getIdNum() {
		return idNum;
	}
	public static void setIdNum(int idNum) {
		Employee.idNum = idNum;
	}
	
	public int getTempIdNum() {
		return tempIdNum;
	}
	public void setTempIdNum(int tempIdNum) {
		this.tempIdNum = tempIdNum;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public void addEmployee(ArrayList<Employee> emplist,Employee e)
	{
		emplist.add(e);
	}
	
	public void removeEmployee(ArrayList<Employee> emplist,int index)
	{
		emplist.remove(index-1);
	}
	
	public void printEmployees(ArrayList<Employee> emplist)
	{
		for(int i=0;i<emplist.size();i++)
		{
			System.out.println("Employee "+(i+1)+"\n"+emplist.get(i));
		}
	}
	public void getManagersEmployees(ArrayList<Employee> emplist)
	{
		int nbmanagers=0;
		
		for(int i=0;i<emplist.size();i++)
		{
			if(emplist.get(i).getPosition().equalsIgnoreCase("manager"))
			{
				System.out.println("Manager "+(nbmanagers+1)+":\n "+emplist.get(i));
				nbmanagers++;
			}
		}
		System.out.println("The current number of manager(s) working as Cashier is  "+nbmanagers+" in total.");
	}
	public void getRegularEmployees(ArrayList<Employee> emplist)
	{
		int nbemployees=0;
		
		for(int i=0;i<emplist.size();i++)
		{
			if(emplist.get(i).getPosition().equalsIgnoreCase("employee"))
			{
				System.out.println("Employee "+(nbemployees+1)+":\n "+emplist.get(i));
				nbemployees++;
			}
		}
		System.out.println("The current number of employee(s) working as Pharma is  "+nbemployees+" in total.");
	}
	public void searchForEmployee(ArrayList<Employee> emplist,String firstName,String lastName,String job)
	{
		int match=0;
		for(int i=0;i<emplist.size();i++)
		{
			if(emplist.get(i).getFirstname().equalsIgnoreCase(firstName) &&
			emplist.get(i).getLastname().equalsIgnoreCase(lastName)) 
			{
				match++;
			}
		}
		if(match==0)
		{
			System.out.println(job+" of name "+firstName+" "+lastName+" does not exists.");
		}
		else if(match==1)
		{
			System.out.println(job+" of name "+firstName+" "+lastName+" exists having the following info:");
			for(int i=0;i<emplist.size();i++)
			{
				if(emplist.get(i).getFirstname().equalsIgnoreCase(firstName) &&
				emplist.get(i).getLastname().equalsIgnoreCase(lastName)) 
				{
					System.out.println(emplist.get(i));
				}
			}
		}
		else
		{
			System.out.println(job+" of name "+firstName+" "+lastName+" exists with "+
								match+" matches having the following info:");
			for(int i=0;i<emplist.size();i++)
			{
				if(emplist.get(i).getFirstname().equalsIgnoreCase(firstName) &&
				emplist.get(i).getLastname().equalsIgnoreCase(lastName)) 
				{
					System.out.println(emplist.get(i));
				}
			}
			
			
			
		}
	}
	
	public String toString()
	{
		return "Employee info:\nId: "+this.id+"\nFirstName: "+this.firstname+"\nLastName: "+this.lastname+"\nGender: "+this.gender+
				"\nDate Of Birth: "+dob.printEmpDate()+"\nDate Of Hiring: "+doh.printEmpDate()+"\nJob:"+this.job+"\nPosition: "+this.position+
				"\nSalary: "+this.salary+" $ "+"\nDegree: "+this.degree+"\nYears Of Experience: "+this.yearsOfExp+"\n";
									
	}
	
	

}
