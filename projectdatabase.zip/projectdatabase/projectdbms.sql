SELECT d.dept_id,dept_name, COUNT(p_id) AS active_project
FROM project p,department d
WHERE d.dept_id=p.dept_id And end_date > "2024-04-30"
GROUP BY d.dept_id , dept_name;